-- MySqlBackup.NET 2.3.8.0
-- Dump Time: 2025-06-30 00:00:04
-- --------------------------------------
-- Server version 8.0.39 MySQL Community Server - GPL


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 
-- Definition of tbl_appmodule
-- 

DROP TABLE IF EXISTS `tbl_appmodule`;
CREATE TABLE IF NOT EXISTS `tbl_appmodule` (
  `ModuleID` int NOT NULL AUTO_INCREMENT,
  `ModuleName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ModuleCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `IsActive` tinyint(1) DEFAULT '1',
  `Sequence` int DEFAULT '0',
  `Tcolor` varchar(50) DEFAULT 'LightGreen',
  `Bcolor` varchar(50) DEFAULT 'DarkGreen',
  `MImage` varchar(50) DEFAULT 'noimage.png',
  PRIMARY KEY (`ModuleID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_appmodule
-- 

/*!40000 ALTER TABLE `tbl_appmodule` DISABLE KEYS */;
INSERT INTO `tbl_appmodule`(`ModuleID`,`ModuleName`,`ModuleCode`,`IsActive`,`Sequence`,`Tcolor`,`Bcolor`,`MImage`) VALUES(1,'POS (NBS)','CashCounter',0,0,'LightGreen','DarkGreen','cashcounter.png'),(2,'Add Item (NBS)','InventoryProduct',0,0,'white','Gray','AddItem.png'),(3,'Scanner Setting','ScannerSetting',1,8,'white','DarkOrange','scannersetting.png'),(4,'Customer Credits','CustomerDue',0,0,'LightGreen','DarkGreen','searchduesale.png'),(5,'Discount and Offer','DiscountOffer',0,0,'white','#C89F0F','discount.png'),(6,'Lable Printer Setting','LPrinterSetting',1,10,'white','gray','printersetting.png'),(7,'Transaction History','TransactionDhashboard',1,6,'white','black','TotalSale.png'),(8,'Exchange Reciept','ExchangeReturn',0,0,'white','Red','Exchange.png'),(9,'Add Purchase Items','PurchaseInvoice',0,0,'white','#2550DD','order.png'),(10,'Label Printing','LabelPrint',1,1,'white','#f48678','1Dcode.png'),(11,'Graph Dashboard','GraphDashboard',1,7,'white','red','graph.png'),(12,'Inventory Edit','InventoryEditing',1,11,'white','black','inventory.png'),(13,'Software Configuration','SoftwareConfiguration',1,9,'#a4ccea','#174c89','SoftwareConfig.png'),(14,'POS (BS)','CashCounterBS',1,3,'LightGreen','DarkGreen','cashcounter.png'),(15,'Add Item(BS)','InventoryProductBS',1,2,'white','gray','AddItem.png'),(16,'Add Quotation','AddQuotation',0,0,'white','Green','cashcounter.png'),(17,'Data Backup','DataBackup',1,9,'white','DarkGreen','databackup.png'),(18,'Item List (BS)','ListItemBS',1,4,'white','gray','Listitem.png'),(19,'Report Dashboard','ReportDhashboard',1,5,'white','#2550DD','report.png');
/*!40000 ALTER TABLE `tbl_appmodule` ENABLE KEYS */;

-- 
-- Definition of tbl_appmoduleaccess
-- 

DROP TABLE IF EXISTS `tbl_appmoduleaccess`;
CREATE TABLE IF NOT EXISTS `tbl_appmoduleaccess` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `GroupID` int NOT NULL,
  `ModuleID` int NOT NULL,
  `Access` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_appmoduleaccess
-- 

/*!40000 ALTER TABLE `tbl_appmoduleaccess` DISABLE KEYS */;
INSERT INTO `tbl_appmoduleaccess`(`ID`,`GroupID`,`ModuleID`,`Access`) VALUES(2,1,1,1),(3,1,2,1),(4,1,3,1),(5,1,4,1),(6,1,5,1),(7,1,6,1),(8,1,7,1),(9,1,8,1),(10,1,9,1),(11,1,10,1),(12,1,11,1),(13,1,12,1),(14,2,1,1),(15,2,2,1),(16,2,3,1),(17,2,4,0),(18,2,5,0),(19,2,6,0),(20,2,7,1),(21,2,8,1),(22,2,9,1),(23,2,10,1),(24,2,11,1),(25,2,12,0),(29,3,1,1),(30,3,2,0),(31,3,3,0),(32,3,4,0),(33,3,5,0),(34,3,6,0),(35,3,7,0),(36,3,8,1),(37,3,9,1),(38,3,10,0),(39,3,11,0),(40,3,12,0),(44,1,13,1),(45,2,13,1),(46,1,14,1),(47,2,14,1),(48,1,15,1),(49,2,15,1),(50,1,16,1),(51,2,16,1),(52,1,17,1),(53,2,17,1),(54,3,17,1),(55,1,18,1),(56,2,18,1),(57,3,18,1),(58,1,19,1),(59,2,19,1),(60,3,19,1);
/*!40000 ALTER TABLE `tbl_appmoduleaccess` ENABLE KEYS */;

-- 
-- Definition of tbl_appsetup
-- 

DROP TABLE IF EXISTS `tbl_appsetup`;
CREATE TABLE IF NOT EXISTS `tbl_appsetup` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `VariableKey` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `VariableDesc` varchar(50) DEFAULT NULL,
  `VariableValue` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_appsetup
-- 

/*!40000 ALTER TABLE `tbl_appsetup` DISABLE KEYS */;
INSERT INTO `tbl_appsetup`(`ID`,`VariableKey`,`VariableDesc`,`VariableValue`) VALUES(1,'ShopName','Shop Name','SADHANA EYE CARE'),(2,'ShopTag','Shop Tag','Eye Surgeon'),(3,'ShopAddress','Shop Address','275 Princess Buiding, Ground Floar, Marine lines, Mumbai 400002'),(4,'ShopMob','Shop Mobile','8104994482'),(5,'ShopMobAlt','Shop Alt Mobile','8104994482'),(6,'ShopEmail','Shop Email','drdiptishah@sadhanaeyecare.com'),(7,'ShopWebsite','Shop Website','NA'),(8,'ShopTerm','Shop Term & Condition','NA'),(9,'RecieptPrinter80MM','Reciept Printer 80MM','EasyMM80D2'),(10,'RecieptPrinterA4','Reciept Printer A4','POS-80C'),(11,'RecieptAs18size','Reciept Size','A4'),(13,'TermAndCondition','Term & Condition','NO RETURN NO EXCHANGE THANKS FOR DOING BUSINESS WOTH US'),(15,'RecieptGap','RecieptGap','25'),(16,'PrinterConnectedWithUSB','Printer Connected With USB','True'),(17,'RecieptPrintCount','Reciept Print Count','2'),(18,'ShopCat','Shop Category','Optics'),(19,'ShopBGImage','Shop BG Image','homeoptics.png'),(20,'ReceiptDesignName','Receipt Design Name','D2');
/*!40000 ALTER TABLE `tbl_appsetup` ENABLE KEYS */;

-- 
-- Definition of tbl_backupdate
-- 

DROP TABLE IF EXISTS `tbl_backupdate`;
CREATE TABLE IF NOT EXISTS `tbl_backupdate` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DateName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_backupdate
-- 

/*!40000 ALTER TABLE `tbl_backupdate` DISABLE KEYS */;
INSERT INTO `tbl_backupdate`(`ID`,`DateName`) VALUES(1,'15.Jun.2025'),(2,'16.Jun.2025'),(3,'16.Jun.2025'),(4,'16.Jun.2025'),(5,'19.Jun.2025'),(6,'23.Jun.2025'),(7,'24.Jun.2025'),(8,'26.Jun.2025'),(9,'27.Jun.2025'),(10,'29.Jun.2025');
/*!40000 ALTER TABLE `tbl_backupdate` ENABLE KEYS */;

-- 
-- Definition of tbl_bankdetail
-- 

DROP TABLE IF EXISTS `tbl_bankdetail`;
CREATE TABLE IF NOT EXISTS `tbl_bankdetail` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `BankName` varchar(100) DEFAULT NULL,
  `AccountNo` varchar(25) DEFAULT NULL,
  `IFSC` varchar(20) DEFAULT NULL,
  `AccHolderName` varchar(100) DEFAULT NULL,
  `BankAddress` varchar(100) DEFAULT NULL,
  `UPIID` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_bankdetail
-- 

/*!40000 ALTER TABLE `tbl_bankdetail` DISABLE KEYS */;
INSERT INTO `tbl_bankdetail`(`ID`,`BankName`,`AccountNo`,`IFSC`,`AccHolderName`,`BankAddress`,`UPIID`) VALUES(1,'BN','AN','IFSC','HNAME','ADDRS','8669205336@ptaxis');
/*!40000 ALTER TABLE `tbl_bankdetail` ENABLE KEYS */;

-- 
-- Definition of tbl_clientdetail
-- 

DROP TABLE IF EXISTS `tbl_clientdetail`;
CREATE TABLE IF NOT EXISTS `tbl_clientdetail` (
  `ClientId` int NOT NULL AUTO_INCREMENT,
  `ClientNo` varchar(100) DEFAULT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `DB_version` varchar(100) DEFAULT NULL,
  `App_Version` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ClientId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_clientdetail
-- 

/*!40000 ALTER TABLE `tbl_clientdetail` DISABLE KEYS */;
INSERT INTO `tbl_clientdetail`(`ClientId`,`ClientNo`,`Name`,`Location`,`DB_version`,`App_Version`) VALUES(1,'UBB-1220-2400-0001','Value Plus','Raymond Thane','2552025.1.0.0','2552025.1.0.0');
/*!40000 ALTER TABLE `tbl_clientdetail` ENABLE KEYS */;

-- 
-- Definition of tbl_customerbuydate
-- 

DROP TABLE IF EXISTS `tbl_customerbuydate`;
CREATE TABLE IF NOT EXISTS `tbl_customerbuydate` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DateName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_customerbuydate
-- 

/*!40000 ALTER TABLE `tbl_customerbuydate` DISABLE KEYS */;
INSERT INTO `tbl_customerbuydate`(`ID`,`DateName`) VALUES(1,'16.Jun.2025'),(2,'16.Jun.2025'),(3,'16.Jun.2025'),(4,'16.Jun.2025'),(5,'16.Jun.2025'),(6,'16.Jun.2025'),(7,'16.Jun.2025'),(8,'16.Jun.2025'),(9,'16.Jun.2025'),(10,'16.Jun.2025'),(11,'16.Jun.2025'),(12,'16.Jun.2025'),(13,'19.Jun.2025'),(14,'19.Jun.2025'),(15,'19.Jun.2025'),(16,'19.Jun.2025'),(17,'19.Jun.2025'),(18,'19.Jun.2025'),(19,'19.Jun.2025'),(20,'23.Jun.2025'),(21,'23.Jun.2025'),(22,'23.Jun.2025'),(23,'23.Jun.2025'),(24,'23.Jun.2025'),(25,'23.Jun.2025'),(26,'24.Jun.2025'),(27,'24.Jun.2025'),(28,'24.Jun.2025'),(29,'24.Jun.2025'),(30,'24.Jun.2025'),(31,'24.Jun.2025'),(32,'24.Jun.2025'),(33,'24.Jun.2025'),(34,'24.Jun.2025'),(35,'24.Jun.2025'),(36,'24.Jun.2025'),(37,'24.Jun.2025'),(38,'24.Jun.2025'),(39,'26.Jun.2025'),(40,'26.Jun.2025'),(41,'26.Jun.2025'),(42,'26.Jun.2025'),(43,'26.Jun.2025'),(44,'26.Jun.2025'),(45,'27.Jun.2025'),(46,'27.Jun.2025'),(47,'27.Jun.2025'),(48,'27.Jun.2025'),(49,'27.Jun.2025'),(50,'27.Jun.2025'),(51,'27.Jun.2025'),(52,'27.Jun.2025'),(53,'27.Jun.2025'),(54,'27.Jun.2025'),(55,'27.Jun.2025'),(56,'27.Jun.2025'),(57,'27.Jun.2025'),(58,'27.Jun.2025'),(59,'27.Jun.2025'),(60,'27.Jun.2025'),(61,'27.Jun.2025'),(62,'27.Jun.2025'),(63,'27.Jun.2025'),(64,'27.Jun.2025'),(65,'27.Jun.2025'),(66,'27.Jun.2025'),(67,'27.Jun.2025'),(68,'27.Jun.2025'),(69,'27.Jun.2025'),(70,'27.Jun.2025'),(71,'29.Jun.2025'),(72,'29.Jun.2025'),(73,'29.Jun.2025'),(74,'29.Jun.2025'),(75,'29.Jun.2025'),(76,'29.Jun.2025'),(77,'29.Jun.2025'),(78,'29.Jun.2025'),(79,'29.Jun.2025'),(80,'29.Jun.2025'),(81,'29.Jun.2025'),(82,'29.Jun.2025'),(83,'29.Jun.2025'),(84,'29.Jun.2025'),(85,'29.Jun.2025'),(86,'29.Jun.2025'),(87,'29.Jun.2025'),(88,'29.Jun.2025'),(89,'29.Jun.2025'),(90,'29.Jun.2025'),(91,'29.Jun.2025'),(92,'29.Jun.2025'),(93,'29.Jun.2025'),(94,'29.Jun.2025'),(95,'29.Jun.2025'),(96,'29.Jun.2025'),(97,'29.Jun.2025'),(98,'29.Jun.2025'),(99,'29.Jun.2025'),(100,'30.Jun.2025');
/*!40000 ALTER TABLE `tbl_customerbuydate` ENABLE KEYS */;

-- 
-- Definition of tbl_customers
-- 

DROP TABLE IF EXISTS `tbl_customers`;
CREATE TABLE IF NOT EXISTS `tbl_customers` (
  `CustomerId` int NOT NULL AUTO_INCREMENT,
  `CustomerName` varchar(50) DEFAULT NULL,
  `CustomerPhone` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`CustomerId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_customers
-- 

/*!40000 ALTER TABLE `tbl_customers` DISABLE KEYS */;
INSERT INTO `tbl_customers`(`CustomerId`,`CustomerName`,`CustomerPhone`) VALUES(1,'Sibaram','1111111111'),(2,'rahgab','2222222222');
/*!40000 ALTER TABLE `tbl_customers` ENABLE KEYS */;

-- 
-- Definition of tbl_dealer
-- 

DROP TABLE IF EXISTS `tbl_dealer`;
CREATE TABLE IF NOT EXISTS `tbl_dealer` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `Mobile` varchar(15) DEFAULT NULL,
  `MobileAlt` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `PGSTNo` varchar(50) DEFAULT NULL,
  `IsActive` tinyint DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_dealer
-- 

/*!40000 ALTER TABLE `tbl_dealer` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_dealer` ENABLE KEYS */;

-- 
-- Definition of tbl_dealer_paid
-- 

DROP TABLE IF EXISTS `tbl_dealer_paid`;
CREATE TABLE IF NOT EXISTS `tbl_dealer_paid` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DealerId` int DEFAULT NULL,
  `PaymentDate` date DEFAULT NULL,
  `PaymentAmount` int DEFAULT NULL,
  `OrderNo` varchar(50) DEFAULT NULL,
  `Description` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '''',
  `ss` varchar(100) DEFAULT '',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_dealer_paid
-- 

/*!40000 ALTER TABLE `tbl_dealer_paid` DISABLE KEYS */;
INSERT INTO `tbl_dealer_paid`(`ID`,`DealerId`,`PaymentDate`,`PaymentAmount`,`OrderNo`,`Description`,`ss`) VALUES(1,2,'2025-01-14 00:00:00',13688,'use25','',''),(2,2,'2025-01-14 00:00:00',200,'3243','',''),(3,2,'2025-01-14 00:00:00',200,'3243','',''),(4,2,'2025-02-01 00:00:00',200,'3243','',''),(5,1,'2025-02-15 00:00:00',51,'sadsda','',''),(6,1,'2025-02-15 00:00:00',9440,'egfbs----4785','',''),(7,2,'2025-02-15 00:00:00',72,'3243','paid on paytm id 2356',''),(8,2,'2025-03-01 00:00:00',5000,'12323','rtjhn  hh','');
/*!40000 ALTER TABLE `tbl_dealer_paid` ENABLE KEYS */;

-- 
-- Definition of tbl_dealer_paid_detail
-- 

DROP TABLE IF EXISTS `tbl_dealer_paid_detail`;
CREATE TABLE IF NOT EXISTS `tbl_dealer_paid_detail` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `OnDate` date DEFAULT NULL,
  `AmountPerInv` int DEFAULT NULL,
  `DearPaidId` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `DearPaidId` (`DearPaidId`),
  CONSTRAINT `tbl_dealer_paid_detail_ibfk_1` FOREIGN KEY (`DearPaidId`) REFERENCES `tbl_dealer_paid` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_dealer_paid_detail
-- 

/*!40000 ALTER TABLE `tbl_dealer_paid_detail` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_dealer_paid_detail` ENABLE KEYS */;

-- 
-- Definition of tbl_easygroupitem
-- 

DROP TABLE IF EXISTS `tbl_easygroupitem`;
CREATE TABLE IF NOT EXISTS `tbl_easygroupitem` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `GroupCode` int DEFAULT '0',
  `SetCode` int DEFAULT '0',
  `GroupName` varchar(100) DEFAULT NULL,
  `ImageURL` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'noimage.png',
  `FontSize` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '20',
  `IsDeleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_easygroupitem
-- 

/*!40000 ALTER TABLE `tbl_easygroupitem` DISABLE KEYS */;
INSERT INTO `tbl_easygroupitem`(`ID`,`GroupCode`,`SetCode`,`GroupName`,`ImageURL`,`FontSize`,`IsDeleted`) VALUES(1,0,0,'test','noimage.png','20',1),(2,2,0,'TROUSER ','trouser.png','20',0),(3,3,0,'TROUSER 28 30','trouser.png','20',0),(4,4,0,'SDDFG','shawl.png','20',0),(5,5,0,'SASD','noimage.png','20',0),(6,6,0,'AAA','noimage.png','20',0),(7,7,0,'BBBB','noimage.png','20',0);
/*!40000 ALTER TABLE `tbl_easygroupitem` ENABLE KEYS */;

-- 
-- Definition of tbl_errorlog
-- 

DROP TABLE IF EXISTS `tbl_errorlog`;
CREATE TABLE IF NOT EXISTS `tbl_errorlog` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `ErrorNumber` varchar(10) DEFAULT NULL,
  `ErrorLine` varchar(10) DEFAULT NULL,
  `ErrorMessage` varchar(4000) DEFAULT NULL,
  `ErrorSeverity` varchar(10) DEFAULT NULL,
  `ErrorState` varchar(10) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `ProcedureName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_errorlog
-- 

/*!40000 ALTER TABLE `tbl_errorlog` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_errorlog` ENABLE KEYS */;

-- 
-- Definition of tbl_gstdetail
-- 

DROP TABLE IF EXISTS `tbl_gstdetail`;
CREATE TABLE IF NOT EXISTS `tbl_gstdetail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `GSTPercentage` int NOT NULL,
  `CGSTPercentage` int NOT NULL,
  `SGSTPercentage` int NOT NULL,
  `GSTNumber` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_gstdetail
-- 

/*!40000 ALTER TABLE `tbl_gstdetail` DISABLE KEYS */;
INSERT INTO `tbl_gstdetail`(`id`,`GSTPercentage`,`CGSTPercentage`,`SGSTPercentage`,`GSTNumber`) VALUES(1,18,9,9,'ADSFS343HHD');
/*!40000 ALTER TABLE `tbl_gstdetail` ENABLE KEYS */;

-- 
-- Definition of tbl_hrf_instruction
-- 

DROP TABLE IF EXISTS `tbl_hrf_instruction`;
CREATE TABLE IF NOT EXISTS `tbl_hrf_instruction` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `HRF_Code` varchar(10) DEFAULT NULL,
  `HRF_Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Show_Hide` tinyint DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_hrf_instruction
-- 

/*!40000 ALTER TABLE `tbl_hrf_instruction` DISABLE KEYS */;
INSERT INTO `tbl_hrf_instruction`(`ID`,`HRF_Code`,`HRF_Name`,`Show_Hide`) VALUES(1,'HRF_1','Item',1),(2,'HRF_2','MRP',1),(3,'HRF_3','Price',1),(4,'HRF_4','Color',1),(5,'HRF_5','Net Weight',1),(6,'HRF_6','Batch No',1),(7,'HRF_7','Energy Value',1),(8,'HRF_8','Protien',1),(9,'HRF_9','Carbohydrade',1),(10,'HRF_10','Fat',1),(11,'HRF_11','Sugar',1),(12,'HRF_12','b',1),(13,'HRF_13','c',1),(14,'HRF_14','d',1),(15,'HRF_15','f',1);
/*!40000 ALTER TABLE `tbl_hrf_instruction` ENABLE KEYS */;

-- 
-- Definition of tbl_hrf_printed_data
-- 

DROP TABLE IF EXISTS `tbl_hrf_printed_data`;
CREATE TABLE IF NOT EXISTS `tbl_hrf_printed_data` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Barcode` varchar(50) DEFAULT NULL,
  `ItemName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `MRP` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SalePrice` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Discount` int DEFAULT NULL,
  `DiscountPercentage` int DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  `HRF_4` varchar(50) DEFAULT NULL,
  `HRF_5` varchar(50) DEFAULT NULL,
  `HRF_6` varchar(50) DEFAULT NULL,
  `HRF_7` varchar(50) DEFAULT NULL,
  `HRF_8` varchar(50) DEFAULT NULL,
  `HRF_9` varchar(50) DEFAULT NULL,
  `HRF_10` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `HRF_11` varchar(50) DEFAULT NULL,
  `HRF_12` varchar(50) DEFAULT NULL,
  `HRF_13` varchar(50) DEFAULT NULL,
  `HRF_14` varchar(50) DEFAULT NULL,
  `HRF_15` varchar(50) DEFAULT NULL,
  `ScanStatus` tinyint DEFAULT '0',
  `Source` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_hrf_printed_data
-- 

/*!40000 ALTER TABLE `tbl_hrf_printed_data` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_hrf_printed_data` ENABLE KEYS */;

-- 
-- Definition of tbl_hrf_printed_data_list
-- 

DROP TABLE IF EXISTS `tbl_hrf_printed_data_list`;
CREATE TABLE IF NOT EXISTS `tbl_hrf_printed_data_list` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Barcode` varchar(50) DEFAULT NULL,
  `ItemName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `MRP` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SalePrice` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Discount` int DEFAULT NULL,
  `DiscountPercentage` int DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  `HRF_4` varchar(50) DEFAULT NULL,
  `HRF_5` varchar(50) DEFAULT NULL,
  `HRF_6` varchar(50) DEFAULT NULL,
  `HRF_7` varchar(50) DEFAULT NULL,
  `HRF_8` varchar(50) DEFAULT NULL,
  `HRF_9` varchar(50) DEFAULT NULL,
  `HRF_10` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `HRF_11` varchar(50) DEFAULT NULL,
  `HRF_12` varchar(50) DEFAULT NULL,
  `HRF_13` varchar(50) DEFAULT NULL,
  `HRF_14` varchar(50) DEFAULT NULL,
  `HRF_15` varchar(50) DEFAULT NULL,
  `ScanStatus` tinyint DEFAULT '0',
  `Source` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_hrf_printed_data_list
-- 

/*!40000 ALTER TABLE `tbl_hrf_printed_data_list` DISABLE KEYS */;
INSERT INTO `tbl_hrf_printed_data_list`(`ID`,`Barcode`,`ItemName`,`MRP`,`SalePrice`,`Discount`,`DiscountPercentage`,`Quantity`,`HRF_4`,`HRF_5`,`HRF_6`,`HRF_7`,`HRF_8`,`HRF_9`,`HRF_10`,`HRF_11`,`HRF_12`,`HRF_13`,`HRF_14`,`HRF_15`,`ScanStatus`,`Source`) VALUES(1,'111','dc','15','15',0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Imported'),(2,'111','dc','15','15',0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Imported'),(4,'9988','bc','14','14',0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Imported'),(5,'9999','ab','13','13',0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Imported');
/*!40000 ALTER TABLE `tbl_hrf_printed_data_list` ENABLE KEYS */;

-- 
-- Definition of tbl_hrf_printing_data
-- 

DROP TABLE IF EXISTS `tbl_hrf_printing_data`;
CREATE TABLE IF NOT EXISTS `tbl_hrf_printing_data` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Barcode` varchar(50) DEFAULT NULL,
  `HRF_1` varchar(50) DEFAULT NULL,
  `HRF_2` varchar(50) DEFAULT NULL,
  `HRF_3` varchar(50) DEFAULT NULL,
  `HRF_4` varchar(50) DEFAULT NULL,
  `HRF_5` varchar(50) DEFAULT NULL,
  `HRF_6` varchar(50) DEFAULT NULL,
  `HRF_7` varchar(50) DEFAULT NULL,
  `HRF_8` varchar(50) DEFAULT NULL,
  `HRF_9` varchar(50) DEFAULT NULL,
  `HRF_10` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `HRF_11` varchar(50) DEFAULT NULL,
  `HRF_12` varchar(50) DEFAULT NULL,
  `HRF_13` varchar(50) DEFAULT NULL,
  `HRF_14` varchar(50) DEFAULT NULL,
  `HRF_15` varchar(50) DEFAULT NULL,
  `Print_Quantity` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_hrf_printing_data
-- 

/*!40000 ALTER TABLE `tbl_hrf_printing_data` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_hrf_printing_data` ENABLE KEYS */;

-- 
-- Definition of tbl_inventory
-- 

DROP TABLE IF EXISTS `tbl_inventory`;
CREATE TABLE IF NOT EXISTS `tbl_inventory` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `GroupCode` int DEFAULT '0',
  `CategoryId` int DEFAULT '0',
  `Barcode` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ItemName` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `MRP` int NOT NULL,
  `BuyPrice` int NOT NULL,
  `SalePrice` int NOT NULL,
  `Discount` int NOT NULL,
  `DiscountPercentage` int NOT NULL,
  `Quantity` int NOT NULL,
  `WholeSaleQuantity` int DEFAULT '1',
  `Expiry` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Description` varchar(100) DEFAULT '',
  `IncludeGSTPercentage` int DEFAULT '0',
  `GSTAmount` decimal(10,2) DEFAULT '0.00',
  `AmountExcludeGST` decimal(10,2) DEFAULT '0.00',
  `Is1Plus1Discount` tinyint(1) DEFAULT '0',
  `ImageName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'noimage.png',
  `Fontsize` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '20',
  `IsActive` int DEFAULT '1',
  `IsFirstItem` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_inventory
-- 

/*!40000 ALTER TABLE `tbl_inventory` DISABLE KEYS */;
INSERT INTO `tbl_inventory`(`Id`,`GroupCode`,`CategoryId`,`Barcode`,`ItemName`,`MRP`,`BuyPrice`,`SalePrice`,`Discount`,`DiscountPercentage`,`Quantity`,`WholeSaleQuantity`,`Expiry`,`Description`,`IncludeGSTPercentage`,`GSTAmount`,`AmountExcludeGST`,`Is1Plus1Discount`,`ImageName`,`Fontsize`,`IsActive`,`IsFirstItem`) VALUES(1,0,0,'111','dc',15,0,15,0,0,2,1,'29.Jun.2025','',0,0.00,0.00,0,'noimage.png','20',1,0),(2,0,0,'9988','bc',14,0,14,0,0,1,1,'29.Jun.2025','',0,0.00,0.00,0,'noimage.png','20',1,0),(3,0,0,'9999','ab',13,0,13,0,0,1,1,'29.Jun.2025','',0,0.00,0.00,0,'noimage.png','20',1,0);
/*!40000 ALTER TABLE `tbl_inventory` ENABLE KEYS */;

-- 
-- Definition of tbl_inventory_inprogress
-- 

DROP TABLE IF EXISTS `tbl_inventory_inprogress`;
CREATE TABLE IF NOT EXISTS `tbl_inventory_inprogress` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Barcode` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ItemName` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `MRP` int NOT NULL,
  `BuyPrice` int NOT NULL,
  `SalePrice` int NOT NULL,
  `Discount` int NOT NULL,
  `DiscountPercentage` int NOT NULL,
  `Quantity` int NOT NULL,
  `Expiry` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Description` varchar(100) DEFAULT '',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_inventory_inprogress
-- 

/*!40000 ALTER TABLE `tbl_inventory_inprogress` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_inventory_inprogress` ENABLE KEYS */;

-- 
-- Definition of tbl_inventory_printed
-- 

DROP TABLE IF EXISTS `tbl_inventory_printed`;
CREATE TABLE IF NOT EXISTS `tbl_inventory_printed` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Barcode` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ItemName` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `MRP` int NOT NULL,
  `BuyPrice` int NOT NULL,
  `SalePrice` int NOT NULL,
  `Discount` int NOT NULL,
  `DiscountPercentage` int NOT NULL,
  `Quantity` int NOT NULL,
  `Expiry` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ScanStatus` tinyint DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_inventory_printed
-- 

/*!40000 ALTER TABLE `tbl_inventory_printed` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_inventory_printed` ENABLE KEYS */;

-- 
-- Definition of tbl_inventory_sold
-- 

DROP TABLE IF EXISTS `tbl_inventory_sold`;
CREATE TABLE IF NOT EXISTS `tbl_inventory_sold` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Barcode` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ItemName` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `MRP` int NOT NULL,
  `BuyPrice` int NOT NULL,
  `SalePrice` int NOT NULL,
  `Discount` int NOT NULL,
  `DiscountPercentage` int NOT NULL,
  `Quantity` int NOT NULL,
  `Expiry` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_inventory_sold
-- 

/*!40000 ALTER TABLE `tbl_inventory_sold` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_inventory_sold` ENABLE KEYS */;

-- 
-- Definition of tbl_inventoryaddedhistory
-- 

DROP TABLE IF EXISTS `tbl_inventoryaddedhistory`;
CREATE TABLE IF NOT EXISTS `tbl_inventoryaddedhistory` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UserName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `AddedTime` datetime DEFAULT NULL,
  `ItemName` varchar(100) DEFAULT NULL,
  `AddedComment` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `DiscountComment` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_inventoryaddedhistory
-- 

/*!40000 ALTER TABLE `tbl_inventoryaddedhistory` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_inventoryaddedhistory` ENABLE KEYS */;

-- 
-- Definition of tbl_inventorycategory
-- 

DROP TABLE IF EXISTS `tbl_inventorycategory`;
CREATE TABLE IF NOT EXISTS `tbl_inventorycategory` (
  `CategoryId` int NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`CategoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_inventorycategory
-- 

/*!40000 ALTER TABLE `tbl_inventorycategory` DISABLE KEYS */;
INSERT INTO `tbl_inventorycategory`(`CategoryId`,`CategoryName`) VALUES(1,'Category 1'),(2,'Category 2'),(3,'Category 3'),(4,'Category 4'),(5,'Category 5'),(6,'Category 6'),(7,'Category 7'),(8,'Category 8');
/*!40000 ALTER TABLE `tbl_inventorycategory` ENABLE KEYS */;

-- 
-- Definition of tbl_inventorymasterunit
-- 

DROP TABLE IF EXISTS `tbl_inventorymasterunit`;
CREATE TABLE IF NOT EXISTS `tbl_inventorymasterunit` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Barcode` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ItemName` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `MRP` int NOT NULL,
  `BuyPrice` int NOT NULL,
  `SalePrice` int NOT NULL,
  `Discount` int NOT NULL,
  `DiscountPercentage` int NOT NULL,
  `Quantity` int NOT NULL,
  `Expiry` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_inventorymasterunit
-- 

/*!40000 ALTER TABLE `tbl_inventorymasterunit` DISABLE KEYS */;
INSERT INTO `tbl_inventorymasterunit`(`Id`,`Barcode`,`ItemName`,`MRP`,`BuyPrice`,`SalePrice`,`Discount`,`DiscountPercentage`,`Quantity`,`Expiry`) VALUES(1,'111','dc',15,0,15,0,0,2,'29.Jun.2025');
/*!40000 ALTER TABLE `tbl_inventorymasterunit` ENABLE KEYS */;

-- 
-- Definition of tbl_invoicenogeneration
-- 

DROP TABLE IF EXISTS `tbl_invoicenogeneration`;
CREATE TABLE IF NOT EXISTS `tbl_invoicenogeneration` (
  `InvoiceNo` int NOT NULL AUTO_INCREMENT,
  `Prifix` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Status` tinyint NOT NULL,
  PRIMARY KEY (`InvoiceNo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_invoicenogeneration
-- 

/*!40000 ALTER TABLE `tbl_invoicenogeneration` DISABLE KEYS */;
INSERT INTO `tbl_invoicenogeneration`(`InvoiceNo`,`Prifix`,`Status`) VALUES(1,'MHE',0);
/*!40000 ALTER TABLE `tbl_invoicenogeneration` ENABLE KEYS */;

-- 
-- Definition of tbl_invoicenogeneration_exchange
-- 

DROP TABLE IF EXISTS `tbl_invoicenogeneration_exchange`;
CREATE TABLE IF NOT EXISTS `tbl_invoicenogeneration_exchange` (
  `InvoiceNo` int NOT NULL AUTO_INCREMENT,
  `Prifix` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Status` tinyint NOT NULL,
  PRIMARY KEY (`InvoiceNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_invoicenogeneration_exchange
-- 

/*!40000 ALTER TABLE `tbl_invoicenogeneration_exchange` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_invoicenogeneration_exchange` ENABLE KEYS */;

-- 
-- Definition of tbl_invoicenoreuse
-- 

DROP TABLE IF EXISTS `tbl_invoicenoreuse`;
CREATE TABLE IF NOT EXISTS `tbl_invoicenoreuse` (
  `ReuseId` int NOT NULL AUTO_INCREMENT,
  `InvoiceNo` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `UsedStatus` tinyint NOT NULL,
  PRIMARY KEY (`ReuseId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_invoicenoreuse
-- 

/*!40000 ALTER TABLE `tbl_invoicenoreuse` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_invoicenoreuse` ENABLE KEYS */;

-- 
-- Definition of tbl_loginhistory
-- 

DROP TABLE IF EXISTS `tbl_loginhistory`;
CREATE TABLE IF NOT EXISTS `tbl_loginhistory` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `UserName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `LogInTime` datetime DEFAULT NULL,
  `LogOutTime` datetime DEFAULT NULL,
  `LogoutComment` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_loginhistory
-- 

/*!40000 ALTER TABLE `tbl_loginhistory` DISABLE KEYS */;
INSERT INTO `tbl_loginhistory`(`ID`,`UserName`,`LogInTime`,`LogOutTime`,`LogoutComment`) VALUES(1,'SIBARAM BEHERA','2025-06-29 18:13:44',NULL,'login success'),(2,'SIBARAM BEHERA','2025-06-29 18:32:47',NULL,'login success'),(3,'SIBARAM BEHERA','2025-06-29 19:07:06',NULL,'login success'),(4,'SIBARAM BEHERA','2025-06-29 19:09:01',NULL,'login success'),(5,'SIBARAM BEHERA','2025-06-29 19:13:42',NULL,'login success'),(6,'SIBARAM BEHERA','2025-06-29 19:16:17',NULL,'login success'),(7,'SIBARAM BEHERA','2025-06-29 21:29:42',NULL,'login success'),(8,'SIBARAM BEHERA','2025-06-29 22:44:06',NULL,'login success'),(9,'SIBARAM BEHERA','2025-06-29 23:18:15',NULL,'login success'),(10,'SIBARAM BEHERA','2025-06-29 23:25:10',NULL,'login success');
/*!40000 ALTER TABLE `tbl_loginhistory` ENABLE KEYS */;

-- 
-- Definition of tbl_moduleaccess
-- 

DROP TABLE IF EXISTS `tbl_moduleaccess`;
CREATE TABLE IF NOT EXISTS `tbl_moduleaccess` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `DisplayName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `userpass` varchar(100) NOT NULL,
  `groupId` int NOT NULL,
  `IsActive` tinyint DEFAULT '1',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_moduleaccess
-- 

/*!40000 ALTER TABLE `tbl_moduleaccess` DISABLE KEYS */;
INSERT INTO `tbl_moduleaccess`(`ID`,`DisplayName`,`username`,`userpass`,`groupId`,`IsActive`) VALUES(1,'SIBARAM BEHERA','ram','abc123',1,1),(2,'RAVI PURAN SAHANI','ravi','abc123',2,1),(3,'sree','abc','abc123',3,1);
/*!40000 ALTER TABLE `tbl_moduleaccess` ENABLE KEYS */;

-- 
-- Definition of tbl_months
-- 

DROP TABLE IF EXISTS `tbl_months`;
CREATE TABLE IF NOT EXISTS `tbl_months` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `MonthText` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_months
-- 

/*!40000 ALTER TABLE `tbl_months` DISABLE KEYS */;
INSERT INTO `tbl_months`(`ID`,`MonthText`) VALUES(1,'January'),(2,'February'),(3,'March'),(4,'April'),(5,'May'),(6,'June'),(7,'July'),(8,'August'),(9,'September'),(10,'October'),(11,'November'),(12,'December');
/*!40000 ALTER TABLE `tbl_months` ENABLE KEYS */;

-- 
-- Definition of tbl_namemaster
-- 

DROP TABLE IF EXISTS `tbl_namemaster`;
CREATE TABLE IF NOT EXISTS `tbl_namemaster` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ItemName` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_namemaster
-- 

/*!40000 ALTER TABLE `tbl_namemaster` DISABLE KEYS */;
INSERT INTO `tbl_namemaster`(`Id`,`ItemName`) VALUES(1,'dc'),(2,'bc'),(3,'ab');
/*!40000 ALTER TABLE `tbl_namemaster` ENABLE KEYS */;

-- 
-- Definition of tbl_number
-- 

DROP TABLE IF EXISTS `tbl_number`;
CREATE TABLE IF NOT EXISTS `tbl_number` (
  `Number` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `PreFix` varchar(14) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Status` int DEFAULT '1',
  PRIMARY KEY (`Number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_number
-- 

/*!40000 ALTER TABLE `tbl_number` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_number` ENABLE KEYS */;

-- 
-- Definition of tbl_order
-- 

DROP TABLE IF EXISTS `tbl_order`;
CREATE TABLE IF NOT EXISTS `tbl_order` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `OrderNo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `TaxRate` int DEFAULT NULL,
  `Tax` int DEFAULT NULL,
  `OrderAmount` int DEFAULT NULL,
  `PaidAmount` int DEFAULT '0',
  `BalanceAmount` int DEFAULT '0',
  `DealerId` int DEFAULT NULL,
  `OrderDate` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_order
-- 

/*!40000 ALTER TABLE `tbl_order` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_order` ENABLE KEYS */;

-- 
-- Definition of tbl_orderdetail
-- 

DROP TABLE IF EXISTS `tbl_orderdetail`;
CREATE TABLE IF NOT EXISTS `tbl_orderdetail` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `OrderId` int DEFAULT NULL,
  `OrderNo` varchar(50) DEFAULT NULL,
  `ItemName` varchar(100) DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  `Rate` int DEFAULT NULL,
  `RateAfterTax` double DEFAULT NULL,
  `Amount` int DEFAULT NULL,
  `ProfitMargin` int DEFAULT NULL,
  `SalePrice` int DEFAULT NULL,
  `MRP` int DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_orderdetail
-- 

/*!40000 ALTER TABLE `tbl_orderdetail` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_orderdetail` ENABLE KEYS */;

-- 
-- Definition of tbl_printers
-- 

DROP TABLE IF EXISTS `tbl_printers`;
CREATE TABLE IF NOT EXISTS `tbl_printers` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `CounterId` int NOT NULL,
  `PrinterType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_printers
-- 

/*!40000 ALTER TABLE `tbl_printers` DISABLE KEYS */;
INSERT INTO `tbl_printers`(`ID`,`CounterId`,`PrinterType`,`Name`) VALUES(1,1,'Receipt','POS-80C'),(2,1,'Label','TSC TTP-244 Pro');
/*!40000 ALTER TABLE `tbl_printers` ENABLE KEYS */;

-- 
-- Definition of tbl_printinghistory
-- 

DROP TABLE IF EXISTS `tbl_printinghistory`;
CREATE TABLE IF NOT EXISTS `tbl_printinghistory` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `PrintedBy` varchar(50) DEFAULT NULL,
  `PrintDate` date DEFAULT NULL,
  `DataSource` varchar(50) DEFAULT NULL,
  `PrintCount` int DEFAULT NULL,
  `PrintItem` varchar(50) DEFAULT NULL,
  `ActionAfterPrint` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_printinghistory
-- 

/*!40000 ALTER TABLE `tbl_printinghistory` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_printinghistory` ENABLE KEYS */;

-- 
-- Definition of tbl_quotationgeneration
-- 

DROP TABLE IF EXISTS `tbl_quotationgeneration`;
CREATE TABLE IF NOT EXISTS `tbl_quotationgeneration` (
  `QuotationNo` int NOT NULL AUTO_INCREMENT,
  `Prifix` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Status` tinyint NOT NULL,
  PRIMARY KEY (`QuotationNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_quotationgeneration
-- 

/*!40000 ALTER TABLE `tbl_quotationgeneration` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_quotationgeneration` ENABLE KEYS */;

-- 
-- Definition of tbl_receiptdesigns
-- 

DROP TABLE IF EXISTS `tbl_receiptdesigns`;
CREATE TABLE IF NOT EXISTS `tbl_receiptdesigns` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Design` varchar(50) DEFAULT NULL,
  `PageName` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `UsedIn` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_receiptdesigns
-- 

/*!40000 ALTER TABLE `tbl_receiptdesigns` DISABLE KEYS */;
INSERT INTO `tbl_receiptdesigns`(`ID`,`Design`,`PageName`,`UsedIn`) VALUES(1,'D1','TempReciept.xaml','CashCounter'),(2,'D2','D2UserControl.xaml','EasyReciept.xaml,D2CashCounter.xaml'),(3,'D3','EasyMM80D2.xaml','EasySale'),(4,'D4','18Reciept.xaml','CashCounter'),(5,'D5','A4Reciept','CashCounter');
/*!40000 ALTER TABLE `tbl_receiptdesigns` ENABLE KEYS */;

-- 
-- Definition of tbl_sale
-- 

DROP TABLE IF EXISTS `tbl_sale`;
CREATE TABLE IF NOT EXISTS `tbl_sale` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `InvoiceNo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ExtraDiscount` int DEFAULT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `CustomerMobile` varchar(15) DEFAULT '',
  `CustomerGST` varchar(50) DEFAULT '',
  `PaymentBy` varchar(50) DEFAULT NULL,
  `GST` decimal(10,2) NOT NULL DEFAULT '0.00',
  `SGST` decimal(10,3) DEFAULT '0.000',
  `CGST` decimal(10,3) DEFAULT '0.000',
  `PaidAmount` int NOT NULL DEFAULT '0',
  `DueAmount` int DEFAULT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'Inprogress',
  `Date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `PayDate` date DEFAULT NULL,
  `IsDeleted` tinyint NOT NULL DEFAULT '0',
  `CounterId` int DEFAULT '0',
  `UserId` int DEFAULT '0',
  `ExcRef` varchar(50) DEFAULT '',
  `ExcAmount` int DEFAULT '0',
  `CashPay` int DEFAULT '0',
  `CardPay` int DEFAULT '0',
  `UPIPay` int DEFAULT '0',
  `TransactionType` varchar(50) DEFAULT 'Sale',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_sale
-- 

/*!40000 ALTER TABLE `tbl_sale` DISABLE KEYS */;
INSERT INTO `tbl_sale`(`ID`,`InvoiceNo`,`ExtraDiscount`,`CustomerName`,`CustomerMobile`,`CustomerGST`,`PaymentBy`,`GST`,`SGST`,`CGST`,`PaidAmount`,`DueAmount`,`Status`,`Date`,`PayDate`,`IsDeleted`,`CounterId`,`UserId`,`ExcRef`,`ExcAmount`,`CashPay`,`CardPay`,`UPIPay`,`TransactionType`) VALUES(1,'MHE1',0,'MHE1','','','Cash',0.00,0.000,0.000,0,0,'Inprogress','2025-06-29 18:36:11',NULL,0,1,0,'',0,0,0,0,'Sale');
/*!40000 ALTER TABLE `tbl_sale` ENABLE KEYS */;

-- 
-- Definition of tbl_sale_exchange
-- 

DROP TABLE IF EXISTS `tbl_sale_exchange`;
CREATE TABLE IF NOT EXISTS `tbl_sale_exchange` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `InvoiceNo` varchar(50) DEFAULT NULL,
  `ExtraDiscount` int DEFAULT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `CustomerMobile` varchar(15) DEFAULT NULL,
  `CustomerGST` varchar(50) DEFAULT NULL,
  `PaymentBy` varchar(50) DEFAULT NULL,
  `GST` int NOT NULL DEFAULT '0',
  `SGST` int DEFAULT NULL,
  `CGST` int DEFAULT NULL,
  `PaidAmount` int NOT NULL DEFAULT '0',
  `DueAmount` int DEFAULT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'Inprogress',
  `Date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IsDeleted` tinyint NOT NULL DEFAULT '0',
  `CounterId` int DEFAULT '0',
  `UserId` int DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_sale_exchange
-- 

/*!40000 ALTER TABLE `tbl_sale_exchange` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_sale_exchange` ENABLE KEYS */;

-- 
-- Definition of tbl_sale_quotation
-- 

DROP TABLE IF EXISTS `tbl_sale_quotation`;
CREATE TABLE IF NOT EXISTS `tbl_sale_quotation` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `InvoiceNo` varchar(50) DEFAULT NULL,
  `ExtraDiscount` int DEFAULT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `CustomerMobile` varchar(15) DEFAULT NULL,
  `CustomerGST` varchar(50) DEFAULT NULL,
  `PaymentBy` varchar(50) DEFAULT NULL,
  `GST` int NOT NULL DEFAULT '0',
  `SGST` int DEFAULT NULL,
  `CGST` int DEFAULT NULL,
  `PaidAmount` int NOT NULL DEFAULT '0',
  `DueAmount` int DEFAULT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'Inprogress',
  `Date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IsDeleted` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_sale_quotation
-- 

/*!40000 ALTER TABLE `tbl_sale_quotation` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_sale_quotation` ENABLE KEYS */;

-- 
-- Definition of tbl_saledetail
-- 

DROP TABLE IF EXISTS `tbl_saledetail`;
CREATE TABLE IF NOT EXISTS `tbl_saledetail` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ItemId` int DEFAULT '0',
  `CategoryId` int DEFAULT '0',
  `InvoiceNo` varchar(50) NOT NULL,
  `GroupCode` int DEFAULT '0',
  `Barcode` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ItemName` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `MRP` int NOT NULL,
  `BuyPrice` int NOT NULL,
  `SalePrice` int NOT NULL,
  `Discount` int NOT NULL,
  `DiscountPercentage` int NOT NULL,
  `Quantity` int NOT NULL,
  `WholeSaleQuantity` int DEFAULT '1',
  `Amount` int NOT NULL,
  `Remark` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ExchangeAmount` int DEFAULT '0',
  `IncludeGSTPercentage` int DEFAULT '0',
  `GSTAmount` decimal(10,2) DEFAULT '0.00',
  `AmountExcludeGST` decimal(10,2) DEFAULT '0.00',
  `Is1Plus1Discount` tinyint(1) DEFAULT '0',
  `ImageName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'noimage.png',
  `Fontsize` varchar(3) DEFAULT '20',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_saledetail
-- 

/*!40000 ALTER TABLE `tbl_saledetail` DISABLE KEYS */;
INSERT INTO `tbl_saledetail`(`Id`,`ItemId`,`CategoryId`,`InvoiceNo`,`GroupCode`,`Barcode`,`ItemName`,`MRP`,`BuyPrice`,`SalePrice`,`Discount`,`DiscountPercentage`,`Quantity`,`WholeSaleQuantity`,`Amount`,`Remark`,`ExchangeAmount`,`IncludeGSTPercentage`,`GSTAmount`,`AmountExcludeGST`,`Is1Plus1Discount`,`ImageName`,`Fontsize`) VALUES(1,0,0,'MHE1',0,'111','DC',15,0,15,0,0,1,1,15,NULL,0,0,0.00,0.00,0,'noimage.png','20');
/*!40000 ALTER TABLE `tbl_saledetail` ENABLE KEYS */;

-- 
-- Definition of tbl_saledetail_exchange
-- 

DROP TABLE IF EXISTS `tbl_saledetail_exchange`;
CREATE TABLE IF NOT EXISTS `tbl_saledetail_exchange` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ItemId` int DEFAULT '0',
  `CategoryId` int DEFAULT '0',
  `InvoiceNo` varchar(50) NOT NULL,
  `GroupCode` int DEFAULT '0',
  `Barcode` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ItemName` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `MRP` int NOT NULL,
  `BuyPrice` int NOT NULL,
  `SalePrice` int NOT NULL,
  `Discount` int NOT NULL,
  `DiscountPercentage` int NOT NULL,
  `Quantity` int NOT NULL,
  `WholeSaleQuantity` int DEFAULT '1',
  `Amount` int NOT NULL,
  `Remark` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `IncludeGSTPercentage` int DEFAULT '0',
  `GSTAmount` decimal(10,2) DEFAULT '0.00',
  `AmountExcludeGST` decimal(10,2) DEFAULT '0.00',
  `Is1Plus1Discount` tinyint(1) DEFAULT '0',
  `ImageName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'noimage.png',
  `Fontsize` varchar(3) DEFAULT '20',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_saledetail_exchange
-- 

/*!40000 ALTER TABLE `tbl_saledetail_exchange` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_saledetail_exchange` ENABLE KEYS */;

-- 
-- Definition of tbl_saledetail_quotation
-- 

DROP TABLE IF EXISTS `tbl_saledetail_quotation`;
CREATE TABLE IF NOT EXISTS `tbl_saledetail_quotation` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `InvoiceNo` varchar(50) NOT NULL,
  `Barcode` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ItemName` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `MRP` int NOT NULL,
  `BuyPrice` int NOT NULL,
  `SalePrice` int NOT NULL,
  `Discount` int NOT NULL,
  `DiscountPercentage` int NOT NULL,
  `Quantity` int NOT NULL,
  `Amount` int NOT NULL,
  `Remark` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `IsMaster` tinyint DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_saledetail_quotation
-- 

/*!40000 ALTER TABLE `tbl_saledetail_quotation` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_saledetail_quotation` ENABLE KEYS */;

-- 
-- Definition of tbl_salehistory
-- 

DROP TABLE IF EXISTS `tbl_salehistory`;
CREATE TABLE IF NOT EXISTS `tbl_salehistory` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `LoginUser` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Customer` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `TotalBill` int DEFAULT NULL,
  `PaidAmount` int DEFAULT NULL,
  `DueAmount` int DEFAULT NULL,
  `DiscountOnBill` int DEFAULT NULL,
  `InvoiceNumner` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_salehistory
-- 

/*!40000 ALTER TABLE `tbl_salehistory` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_salehistory` ENABLE KEYS */;

-- 
-- Definition of tbl_scannersettings
-- 

DROP TABLE IF EXISTS `tbl_scannersettings`;
CREATE TABLE IF NOT EXISTS `tbl_scannersettings` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `DataBits` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `ComPort` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Comm_Type` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `CustomName` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Flow` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `Parity` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `PrinterIp` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `PrinterPort` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `DeviceNumber` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `BaudRate` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `StopBits` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `CounterId` int DEFAULT '1',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_scannersettings
-- 

/*!40000 ALTER TABLE `tbl_scannersettings` DISABLE KEYS */;
INSERT INTO `tbl_scannersettings`(`Id`,`DataBits`,`ComPort`,`Comm_Type`,`CustomName`,`Flow`,`Parity`,`PrinterIp`,`PrinterPort`,`DeviceNumber`,`BaudRate`,`StopBits`,`CounterId`) VALUES(1,'7','COM3','','Scanner_1','None','None','','','Scanner_1','9600','1',1),(2,'7','COM4','1','Zebra_Printer_1','None','None','','','Zebra_Printer_1','9600','1',1);
/*!40000 ALTER TABLE `tbl_scannersettings` ENABLE KEYS */;

-- 
-- Definition of tbl_useraudit
-- 

DROP TABLE IF EXISTS `tbl_useraudit`;
CREATE TABLE IF NOT EXISTS `tbl_useraudit` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `AdminName` varchar(50) DEFAULT NULL,
  `Actions` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ActionDate` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_useraudit
-- 

/*!40000 ALTER TABLE `tbl_useraudit` DISABLE KEYS */;

/*!40000 ALTER TABLE `tbl_useraudit` ENABLE KEYS */;

-- 
-- Definition of tbl_usergroup
-- 

DROP TABLE IF EXISTS `tbl_usergroup`;
CREATE TABLE IF NOT EXISTS `tbl_usergroup` (
  `GroupID` int NOT NULL AUTO_INCREMENT,
  `GroupName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`GroupID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 
-- Dumping data for table tbl_usergroup
-- 

/*!40000 ALTER TABLE `tbl_usergroup` DISABLE KEYS */;
INSERT INTO `tbl_usergroup`(`GroupID`,`GroupName`) VALUES(1,'Supper Admin'),(2,'Admin'),(3,'Operator');
/*!40000 ALTER TABLE `tbl_usergroup` ENABLE KEYS */;

-- 
-- Dumping functions
-- 

DROP FUNCTION IF EXISTS `fntbl_abc`;
DELIMITER |
CREATE FUNCTION `fntbl_abc`() RETURNS varchar(10) CHARSET utf8mb4
    NO SQL
    DETERMINISTIC
    SQL SECURITY INVOKER
BEGIN
DECLARE var_abc varchar(100); 
select name into var_abc from tbl_employee limit 1;
return var_abc;
END |
DELIMITER ;

-- 
-- Dumping procedures
-- 

DROP PROCEDURE IF EXISTS `GeInventoryMasterUnitNameList`;
DELIMITER |
CREATE PROCEDURE `GeInventoryMasterUnitNameList`(
)
BEGIN
select 	distinct ItemName
from tbl_inventorymasterunit order by ITemName asc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `GetInventoryNameList`;
DELIMITER |
CREATE PROCEDURE `GetInventoryNameList`(
)
BEGIN
select ItemName from tbl_namemaster order by ItemName asc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `GetInventoryNameList_PreSale`;
DELIMITER |
CREATE PROCEDURE `GetInventoryNameList_PreSale`(
)
BEGIN
select 	distinct ItemName
from tbl_inventory  order by ItemName asc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `GetInventorySearchList_PreSale`;
DELIMITER |
CREATE PROCEDURE `GetInventorySearchList_PreSale`(
arg_Text varchar(200)
)
BEGIN
select count(barcode) as Quantity,ItemName, MRP,SalePrice, Discount, DiscountPercentage
from 
`tbl_inventory` 
where ItemName like concat('%',arg_Text,'%')
group by ItemName, MRP,SalePrice, Discount, DiscountPercentage;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_BarcodeItemList`;
DELIMITER |
CREATE PROCEDURE `Sp_BarcodeItemList`()
BEGIN
select 	inv.ID,inv.GroupCode, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, Quantity, Expiry, 
Description, IncludeGSTPercentage, GSTAmount, AmountExcludeGST, Is1Plus1Discount, 
ImageName, inv.Fontsize ,git.GroupName,inv.CategoryId,cat.CategoryName,inv.WholeSaleQuantity
from  `tbl_inventory` inv
left join  tbl_easygroupitem git on inv.GroupCode = git.GroupCode
left join tbl_inventorycategory cat on inv.CategoryId = cat.CategoryId
where inv.groupcode = 0 
order by inv.ItemName asc;  
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_CheckDuplicateFromLabelPrinting`;
DELIMITER |
CREATE PROCEDURE `Sp_CheckDuplicateFromLabelPrinting`( 
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50)
)
BEGIN
DECLARE var_barcodecheck varchar(100);
DECLARE var_name varchar(100);
DECLARE var_Masterbarcodecheck varchar(100);
DECLARE var_mastername varchar(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_CheckDuplicateFromLabelPrinting');
END;
START TRANSACTION;
set var_Masterbarcodecheck ='';
set var_mastername ='';
set var_barcodecheck ='';
select barcode into var_barcodecheck from tbl_inventory where barcode= arg_Barcode limit 1;
IF (var_barcodecheck = '')
then
SELECT '0' AS Duplicate,arg_ItemName as ItemName ;
ELSE
select barcode into var_Masterbarcodecheck from tbl_inventorymasterunit where barcode= arg_Barcode limit 1;
select ItemName into var_mastername from tbl_inventorymasterunit where barcode= arg_Barcode limit 1;
IF (var_Masterbarcodecheck = '')
then
SELECT '1' AS Duplicate, arg_ItemName as ItemName; 
else
SELECT '9' AS Duplicate , var_mastername as ItemName; 
end if;
END IF;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_CreateGroupAccess`;
DELIMITER |
CREATE PROCEDURE `Sp_CreateGroupAccess`( 
asg_GroupID int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_CreateGroupAccess');
END;
START TRANSACTION;
if not (select count(groupID) from  tbl_appmodule where groupid=asg_GroupID) then
insert into `tbl_appmoduleaccess` 
(GroupID, ModuleID, Access)
select asg_GroupID,ModuleID,0 from tbl_appmoduleaccess where GroupID=1;
end if;
select LAST_INSERT_ID() as GroupAccessId;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Dashboard_GetInventoryAddHistory`;
DELIMITER |
CREATE PROCEDURE `Sp_Dashboard_GetInventoryAddHistory`(
arg_MonthName NVARCHAR(50)
)
BEGIN
select 	year(now()) `Year`, UserName, AddedTime, ItemName, AddedComment 
from `tbl_inventoryaddedhistory`  where year(addedtime) = year(now())  and monthname(addedtime) = arg_MonthName 
and  DiscountComment is null order by id desc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Dashboard_GetInventoryDicountHistory`;
DELIMITER |
CREATE PROCEDURE `Sp_Dashboard_GetInventoryDicountHistory`(
arg_MonthName NVARCHAR(50)
)
BEGIN
select 	year(now()) `Year`, UserName, AddedTime, ItemName, DiscountComment 
from `tbl_inventoryaddedhistory`  where year(addedtime) = year(now())  and monthname(addedtime) = arg_MonthName 
and  AddedComment is null order by id desc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_DeleteHRFPrinted`;
DELIMITER |
CREATE PROCEDURE `Sp_DeleteHRFPrinted`(                
arg_Id int
)
BEGIN
declare varbacode NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_DeleteHRFPrinted');
END;
START TRANSACTION;
delete from tbl_hrf_printed_data where ID = arg_Id;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_DeleteHRFPrinting`;
DELIMITER |
CREATE PROCEDURE `Sp_DeleteHRFPrinting`(                
arg_ID int
)
BEGIN
declare varbacode NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_DeleteHRFPrinting');
END;
START TRANSACTION;
delete from tbl_hrf_printing_data where id = arg_ID;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_DeleteInventory`;
DELIMITER |
CREATE PROCEDURE `Sp_DeleteInventory`(                
arg_Barcode NVARCHAR(50)
)
BEGIN
declare varbacode NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_DeleteInventory');
END;
START TRANSACTION;
delete from tbl_inventory where Barcode = arg_Barcode;
delete from tbl_inventory_inprogress where Barcode = arg_Barcode;
delete from tbl_inventorymasterunit where Barcode = arg_Barcode;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_DeleteNumber`;
DELIMITER |
CREATE PROCEDURE `Sp_DeleteNumber`(                
arg_Barcode NVARCHAR(50)
)
BEGIN
declare varbacode NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_DeleteNumber');
END;
START TRANSACTION;
delete from tbl_number where Number = arg_Barcode;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_DeletePrintedInventory`;
DELIMITER |
CREATE PROCEDURE `Sp_DeletePrintedInventory`(                
arg_Barcode NVARCHAR(50)
)
BEGIN
declare varbacode NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_DeletePrintedInventory');
END;
START TRANSACTION;
delete from tbl_inventory_printed where Barcode = arg_Barcode;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_DeleteQuotationSale`;
DELIMITER |
CREATE PROCEDURE `Sp_DeleteQuotationSale`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_ItemName NVARCHAR(100)
)
BEGIN
declare varbacode NVARCHAR(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_DeleteQuotationSale');
END;
START TRANSACTION;
delete from tbl_saledetail_quotation where ItemName = arg_ItemName;
select ItemName into varbacode from tbl_saledetail_quotation where InvoiceNo = arg_InvoiceNumber limit 1;
if( varbacode is null) 
then
update  tbl_sale_quotation set IsDeleted = 1 where InvoiceNo = arg_InvoiceNumber;
end if; 
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_DeleteSale`;
DELIMITER |
CREATE PROCEDURE `Sp_DeleteSale`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_Barcode NVARCHAR(50)
)
BEGIN
declare varbacode NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_DeleteSale');
END;
START TRANSACTION;
delete from tbl_saledetail where Barcode = arg_Barcode and InvoiceNo = arg_InvoiceNumber;
select barcode into varbacode from tbl_saledetail where InvoiceNo = arg_InvoiceNumber limit 1;
if( varbacode is null) 
then
update  tbl_sale set IsDeleted = 1 ,InvoiceNo = concat(InvoiceNo,'-reuse') where InvoiceNo = arg_InvoiceNumber;
insert into tbl_invoicenoreuse(InvoiceNo,UsedStatus) values(arg_InvoiceNumber,0);
end if; 
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyCounterAndUserSaleRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyCounterAndUserSaleRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_UserID int,
arg_PaymentType varchar(50),
arg_TransactionType varchar(50)
)
BEGIN
if (arg_FDate <> '' and  arg_TDate <> '') 
then
select sum(bycash) as CashPay ,sum(bycard) as CardPay, sum(byupi) as UPIPay,
(sum(bycash) +sum(bycard)+ sum(byupi)) as CounterSale ,counterid as CounterNumber 
,convert(arg_FDate,date) as FDate
,convert(arg_TDate,date) as TDate
from
(
select sum(cashpayment) as bycash ,sum(cardpayment) as bycard ,sum(upipayment) as byupi ,counterid,userid 
,ifnull(mc.DisplayName,'') as DisplayName
from vtbl_sale_gb_cputd 
left join tbl_moduleaccess mc on UserId = mc.ID
where  SaleDate between  arg_FDate  and  arg_TDate
and (UserId = arg_UserID or arg_UserID = 0)
and (PaymentBy = arg_PaymentType or arg_PaymentType ='')
and (TransactionType = arg_TransactionType or arg_TransactionType = '')
group by counterid,userid
) as T  group by counterid;
end if;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyCounterSaleRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyCounterSaleRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_UserID int,
arg_PaymentType varchar(50),
arg_TransactionType varchar(50)
)
BEGIN
declare varMulti varchar(20);
set varMulti = 'Multi';
if(arg_PaymentType = 'Exc' or arg_TransactionType = 'Exc' )
then
set arg_TransactionType = 'Exc';
set arg_PaymentType = 'Exc';
set varMulti = 'Exc';
end if;
if (arg_FDate <> '' and  arg_TDate <> '') 
then
select case when arg_PaymentType = 'Cash' then sum(T.CashPay) 
when arg_PaymentType = 'Card' then sum(T.CardPay)
when arg_PaymentType = 'UPI' then sum(T.UPIPay)
else ifnull(sum(T.PaidAmount),0) end as CounterSale
, ifnull(T.CounterId,0) as CounterNumber,Sum(ifnull(ExcAmount,0)) as ExcAmount
,convert(arg_FDate,date) as FDate
,convert(arg_TDate,date) as TDate from
(
select 	convert(`Date`,date) as PaymentDate,PaymentBy,PaidAmount, `Status` as InvStatus,
PayDate, IsDeleted, CounterId, UserId, ExcRef, ExcAmount, CashPay, 
CardPay, UPIPay, TransactionType 
from tbl_sale 
where isdeleted = 0 
and `status` <> 'Inprogress' 
and convert(`Date`,date) between  arg_FDate  and  arg_TDate		
and CounterId <> 0 and (TransactionType = arg_TransactionType or arg_TransactionType = '')
) as T 
where (T.UserId = arg_UserID or arg_UserID = 0)
and (T.PaymentBy = arg_PaymentType or arg_PaymentType ='')
or T.PaymentBy = varMulti		
group by T.CounterId order by T.CounterId asc;
end if;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyCounterWiseSaleRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyCounterWiseSaleRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_UserID int,
arg_PaymentType varchar(50),
arg_TransactionType varchar(50)
)
BEGIN
declare varMulti varchar(20);
set varMulti = 'Multi';
if(arg_PaymentType = 'Exc' or arg_TransactionType = 'Exc' )
then
set arg_TransactionType = 'Exc';
set arg_PaymentType = 'Exc';
set varMulti = 'Exc';
end if;
if (arg_FDate <> '' and  arg_TDate <> '') 
then
select sum(bycash) as CashPay ,sum(bycard) as CardPay, sum(byupi) as UPIPay,
(sum(bycash) +sum(bycard)+ sum(byupi)) as CounterSale ,counterid as CounterNumber 
,convert(arg_FDate,date) as FDate
,convert(arg_TDate,date) as TDate
from
(
select sum(cashpayment) as bycash ,sum(cardpayment) as bycard ,sum(upipayment) as byupi ,counterid,userid 
,ifnull(mc.DisplayName,'') as DisplayName,TransactionType
from vtbl_sale_gb_cputd 
left join tbl_moduleaccess mc on UserId = mc.ID
where  SaleDate between  arg_FDate  and  arg_TDate
and (UserId = arg_UserID or arg_UserID = 0)
and (PaymentBy = arg_PaymentType or arg_PaymentType ='')
or PaymentBy = varMulti
group by counterid,userid,TransactionType
) as T  where (TransactionType = arg_TransactionType or arg_TransactionType = '')
group by counterid;
end if;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyCustomerRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyCustomerRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_FSale int,
arg_TSale int
)
BEGIN
select  cm.CustomerId ,cm.CustomerName, cm.CustomerPhone  ,ifnull(count(CustomerMobile),0) as SaleCount,
ifnull(sum(PaidAmount),0) as TotalSale,ifnull(sum(ExcAmount),0) as TotalExchange
from
(
select 	`Date` as PaymentDate,InvoiceNo, ExtraDiscount, CustomerName, CustomerMobile
, CustomerGST, PaymentBy, GST, SGST, CGST, 
PaidAmount, DueAmount, `Status` as InvStatus, PayDate, IsDeleted, CounterId, UserId, ExcRef, ExcAmount, CashPay, 
CardPay, UPIPay, TransactionType 
from tbl_sale 
where isdeleted = 0 
and `status` <> 'Inprogress' 
and (
(convert(`Date`,date) BETWEEN COALESCE(NULLIF(arg_FDate, ''), `Date`) 
AND COALESCE(NULLIF(arg_TDate, ''), `Date`))
OR (arg_FDate IS NULL OR arg_FDate = '')
)
) as T 	right join tbl_customers cm on cm.CustomerPhone = T.CustomerMobile
group by CustomerName, CustomerMobile having (arg_FSale = 0 or TotalSale > arg_FSale ) 
and (arg_TSale =0 or  TotalSale < arg_TSale) ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyDeleteSale`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyDeleteSale`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_ItemId int
)
BEGIN
declare varbacode NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_DeleteSale');
END;
START TRANSACTION;
delete from tbl_saledetail where ItemId = arg_ItemId and InvoiceNo = arg_InvoiceNumber;
select barcode into varbacode from tbl_saledetail where InvoiceNo = arg_InvoiceNumber limit 1;
if( varbacode is null) 
then
update  tbl_sale set IsDeleted = 1 ,InvoiceNo = concat(InvoiceNo,'-reuse') where InvoiceNo = arg_InvoiceNumber;
insert into tbl_invoicenoreuse(InvoiceNo,UsedStatus) values(arg_InvoiceNumber,0);
end if; 
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyExcAndExcSaleRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyExcAndExcSaleRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_UserID int
)
BEGIN
if (arg_FDate <> '' and  arg_TDate <> '') 
then
select PaymentDate,InvoiceNo, ExtraDiscount, CustomerName, CustomerMobile
, CustomerGST, PaymentBy, GST, SGST, CGST, 
PaidAmount, DueAmount, InvStatus, PayDate, IsDeleted, CounterId, UserId, ExcRef, ExcAmount, CashPay, 
CardPay, UPIPay, TransactionType  
, ifnull(T.UserId,0) as UserId,mc.DisplayName
,convert(arg_FDate,date) as FDate
,convert(arg_TDate,date) as TDate from
(
select 	`Date` as PaymentDate,InvoiceNo, ExtraDiscount, CustomerName, CustomerMobile
, CustomerGST, PaymentBy, GST, SGST, CGST, 
PaidAmount, DueAmount, `Status` as InvStatus, PayDate, IsDeleted, CounterId, UserId, ExcRef, ExcAmount, CashPay, 
CardPay, UPIPay, TransactionType 
from tbl_sale 
where isdeleted = 0 
and `status` <> 'Inprogress' 
and convert(`Date`,date) between  arg_FDate  and  arg_TDate		
and CounterId <> 0 and TransactionType in('Exc','Exc Sale') 
) as T inner join tbl_moduleaccess mc on T.UserId = mc.ID
where (UserId = arg_UserID or arg_UserID = 0)		
order by PaymentDate desc;
end if;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyExchangeDeleteSale`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyExchangeDeleteSale`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_ItemId int
)
BEGIN
declare varbacode NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyExchangeDeleteSale');
END;
START TRANSACTION;
delete from tbl_saledetail_exchange where ItemId = arg_ItemId and InvoiceNo = arg_InvoiceNumber;
select barcode into varbacode from tbl_saledetail_exchange where InvoiceNo = arg_InvoiceNumber limit 1;
if( varbacode is null) 
then
update  tbl_sale_exchange set IsDeleted = 1 where InvoiceNo = arg_InvoiceNumber;
end if; 
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyExchangeGetInprogressInvoiceNoList`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyExchangeGetInprogressInvoiceNoList`(
)
BEGIN
select 	distinct sa.invoiceNo
from tbl_saledetail_exchange sd
inner join tbl_sale_exchange sa on sd.InvoiceNo = sa.InvoiceNo 
where sa.IsDeleted = 0 and sa.Status = 'Inprogress';
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyExchangeGetInprogressSaleOneByOne`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyExchangeGetInprogressSaleOneByOne`(
arg_InvoiceNo NVARCHAR(50)
)
BEGIN
select  sd.invoiceNo, sd.Barcode, sd.ItemName, sd.MRP, sd.BuyPrice, sd.SalePrice, sd.Discount, sd.DiscountPercentage, sd.Quantity, sd.Amount,
sa.CustomerName, sa.Date, 
CASE ifnull(mi.barcode,'')
WHEN '' THEN false	     
ELSE true
END as 'IsMasterItem' ,GroupCode, IncludeGSTPercentage, GSTAmount, AmountExcludeGST, Is1Plus1Discount,ImageName, Fontsize,sd.ItemId
from tbl_saledetail_exchange sd
inner join tbl_sale_exchange sa on sd.InvoiceNo = sa.InvoiceNo 
left join tbl_inventorymasterunit mi on sd.barcode = mi.barcode
where sa.IsDeleted = 0 and sa.Status = 'Inprogress' and sa.InvoiceNo = arg_InvoiceNo ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyExchangeGetSubsetItemList`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyExchangeGetSubsetItemList`(
arg_Invoice varchar(25)
)
BEGIN
select 	inv.Id as ItemId,inv.GroupCode, inv.Barcode, inv.ItemName, inv.MRP, inv.BuyPrice, inv.SalePrice, inv.Discount, 
inv.DiscountPercentage, inv.Quantity,'' as Description, inv.IncludeGSTPercentage, inv.GSTAmount, inv.AmountExcludeGST, inv.Is1Plus1Discount, 
inv.ImageName, inv.Fontsize ,'' as GroupName,inv.SalePrice as Amount
from  `tbl_saledetail` sd
inner join tbl_inventory inv on sd.ItemId = inv.Id
where sd.InvoiceNo =  arg_Invoice
order by inv.id asc;  
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyExchangeInsertSale`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyExchangeInsertSale`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int,
arg_GSTAmount decimal,
arg_AmountExcludeGST decimal,
arg_ItemId int,
arg_IncludeGSTPercentage int,
arg_Is1Plus1Discount tinyint,
arg_ImageName varchar(50),
arg_Fontsize varchar(3),
arg_GroupCode int,
arg_CategoryId int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyExchangeInsertSale');
END;
START TRANSACTION;
insert into tbl_saledetail_exchange
(ItemId,InvoiceNo,GroupCode, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, 
DiscountPercentage, Quantity, Amount,IncludeGSTPercentage,GSTAmount,AmountExcludeGST
,Is1Plus1Discount,ImageName,Fontsize,CategoryId)
values
(arg_ItemId,arg_InvoiceNumber,arg_GroupCode, arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, 
arg_DiscountPercentage, arg_Quantity, arg_Amount,arg_IncludeGSTPercentage,arg_GSTAmount,
arg_AmountExcludeGST,arg_Is1Plus1Discount,arg_ImageName,arg_Fontsize,arg_CategoryId);
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyExchangeInsertSaleCreateInvoice`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyExchangeInsertSaleCreateInvoice`(  
arg_GroupCode int,
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int,
arg_GSTAmount decimal,
arg_AmountExcludeGST decimal,
arg_ItemId int,
arg_IncludeGSTPercentage int,
arg_Is1Plus1Discount tinyint,
arg_ImageName varchar(50),
arg_Fontsize varchar(3),
arg_CategoryId int
)
BEGIN
DECLARE VAR_INVOICENO NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyExchangeInsertSaleCreateInvoice');
END;
START TRANSACTION;
insert into tbl_invoicenogeneration_exchange(Prifix) values('EXC');
select CONCAT('EXC',max(InvoiceNo)) INTO VAR_INVOICENO from tbl_invoicenogeneration_exchange;
insert into  tbl_sale_exchange 
(InvoiceNo, ExtraDiscount, CustomerName, PaymentBy, SGST, CGST, 
DueAmount)
values
(VAR_INVOICENO, 0, VAR_INVOICENO, 'Cash', 0, 0,	0);
insert into tbl_saledetail_exchange
(ItemId,InvoiceNo, GroupCode,Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, 
DiscountPercentage, Quantity, Amount,IncludeGSTPercentage,GSTAmount,AmountExcludeGST
,Is1Plus1Discount,ImageName,Fontsize,CategoryId)
values
(arg_ItemId,VAR_INVOICENO, arg_GroupCode,arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, 
arg_DiscountPercentage, arg_Quantity, arg_Amount,arg_IncludeGSTPercentage,arg_GSTAmount,
arg_AmountExcludeGST,arg_Is1Plus1Discount,arg_ImageName,arg_Fontsize,arg_CategoryId);
Select VAR_INVOICENO as InvoiceNumber;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyExchangeUpdateSale`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyExchangeUpdateSale`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int,
arg_GSTAmount decimal,
arg_AmountExcludeGST decimal,
arg_ItemId int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyExchangeUpdateSale');
END;
START TRANSACTION;
update tbl_saledetail_exchange set 
Discount = arg_Discount, 
Quantity =arg_Quantity, Amount = arg_Amount,GSTAmount = arg_GSTAmount ,AmountExcludeGST = arg_AmountExcludeGST 
where ItemId = arg_ItemId and InvoiceNo = arg_InvoiceNumber;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyExchangeUpdateSaleDetail`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyExchangeUpdateSaleDetail`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_ExtraDiscount int,
arg_CustomerName NVARCHAR(50),
arg_PaymentBy NVARCHAR(20),	 
arg_GST int, 
arg_DueAmount int,
arg_Status NVARCHAR(50),
arg_PaidAmount int,
arg_CustomerMobile NVARCHAR(50),
arg_CustomerGST NVARCHAR(50),
arg_LoginUser  NVARCHAR(50)
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyExchangeUpdateSaleDetail');
END;
START TRANSACTION;
update tbl_sale_exchange set 
ExtraDiscount = arg_ExtraDiscount, 
CustomerName = arg_CustomerName, PaymentBy = arg_PaymentBy,
GST = arg_GST, DueAmount = arg_DueAmount,`Status` = arg_Status,
PaidAmount = arg_PaidAmount,CustomerMobile= arg_CustomerMobile, CustomerGST = arg_CustomerGST
where InvoiceNo = arg_InvoiceNumber;
insert into `tbl_salehistory` 
(LoginUser, Customer, TotalBill, PaidAmount, DueAmount, DiscountOnBill, 
InvoiceNumner, Date)
values
(arg_LoginUser, arg_CustomerName, (arg_ExtraDiscount+arg_DueAmount+arg_PaidAmount), arg_PaidAmount, arg_DueAmount, arg_ExtraDiscount, 
arg_InvoiceNumber, now());
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyGetCategoryList`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyGetCategoryList`(
)
BEGIN
DECLARE paidamount int;
select 	CategoryId, CategoryName 
from `tbl_inventorycategory` 
order by CategoryName asc;	
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyGetGroupItemList`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyGetGroupItemList`()
BEGIN
select 	gi.ID, gi.GroupCode, gi.GroupName, gi.ImageURl, gi.FontSize,ifnull(inv.SalePrice,0) as SalePrice
,ifnull(inv.Is1Plus1Discount,0) as Is1Plus1Discount
from `tbl_easygroupitem` gi
left join tbl_inventory inv on gi.GroupCode = inv.GroupCode and inv.IsFirstItem=1
where gi.groupcode <> 0
order by gi.GroupName; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyGetSaleByInvoiceNo`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyGetSaleByInvoiceNo`(
arg_InvoiceNo NVARCHAR(50)
)
BEGIN
select   CategoryId, InvoiceNo, GroupCode, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, WholeSaleQuantity, Amount, Remark, IncludeGSTPercentage, GSTAmount, AmountExcludeGST
from tbl_saledetail 	
where  InvoiceNo = arg_InvoiceNo ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyGetSubsetItemList`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyGetSubsetItemList`()
BEGIN
select 	inv.ID,inv.GroupCode, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, Quantity, Expiry, 
Description, IncludeGSTPercentage, GSTAmount, AmountExcludeGST, Is1Plus1Discount, 
ImageName, inv.Fontsize ,git.GroupName,inv.CategoryId,cat.CategoryName,inv.WholeSaleQuantity
from  `tbl_inventory` inv
inner join  tbl_easygroupitem git on inv.GroupCode = git.GroupCode
inner join tbl_inventorycategory cat on inv.CategoryId = cat.CategoryId
where inv.groupcode <> 0 
order by inv.ItemName asc;  
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyInsertGroup`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyInsertGroup`(  
arg_GroupItemCode int,	
arg_GroupName NVARCHAR(50),
arg_ImageName NVARCHAR(50),
arg_LoginUser NVARCHAR(100)
)
BEGIN
DECLARE VAR_GroupCode int;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyInsertGroup');
END;
START TRANSACTION;
select max(ID) INTO VAR_GroupCode from tbl_easygroupitem;
insert into `tbl_easygroupitem` 
(GroupCode, GroupName, ImageURL)
values
(VAR_GroupCode+1, arg_GroupName, arg_ImageName);
select LAST_INSERT_ID() as GroupId; 
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyInsertGroupAndItem`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyInsertGroupAndItem`(  
arg_GroupItemCode int,	
arg_GroupName NVARCHAR(50),
arg_ImageName NVARCHAR(50),
arg_LoginUser NVARCHAR(100),
arg_CategoryId int,
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int, 
arg_SalePrice int,
arg_Quantity int,
arg_WholeSaleQuantity int,
arg_IncludeGSTPercentage int,
arg_GSTAmount decimal(10,2),
arg_AmountExcludeGST decimal(10,2),
arg_Is1Plus1Discount int,
arg_IsFirstItem int
)
BEGIN
DECLARE VAR_GroupCode int;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyInsertGroupAndItem');
END;
START TRANSACTION;
select max(ID) INTO VAR_GroupCode from tbl_easygroupitem;
insert into `tbl_easygroupitem` 
(GroupCode, GroupName, ImageURL)
values
(VAR_GroupCode+1, arg_GroupName, arg_ImageName);
insert into  `tbl_inventory` 
(GroupCode, CategoryId, Barcode, ItemName, MRP,  
SalePrice,  Quantity, WholeSaleQuantity, 
IncludeGSTPercentage, GSTAmount, AmountExcludeGST, 
Is1Plus1Discount, ImageName,IsFirstItem)
values
(VAR_GroupCode+1, arg_CategoryId, arg_Barcode, arg_ItemName,arg_MRP,  
arg_SalePrice,  arg_Quantity, arg_WholeSaleQuantity, 
arg_IncludeGSTPercentage, arg_GSTAmount, arg_AmountExcludeGST, 
arg_Is1Plus1Discount, arg_ImageName,arg_IsFirstItem);
select VAR_GroupCode+1 as GroupId; 
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyInsertItem`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyInsertItem`(  
arg_GroupItemCode int,
arg_ImageName NVARCHAR(50),
arg_LoginUser NVARCHAR(100),
arg_CategoryId int,
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int, 
arg_SalePrice int,
arg_Quantity int,
arg_WholeSaleQuantity int,
arg_IncludeGSTPercentage int,
arg_GSTAmount decimal(10,2),
arg_AmountExcludeGST decimal(10,2),
arg_Is1Plus1Discount int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyInsertItem');
END;
START TRANSACTION;
insert into  `tbl_inventory` 
(GroupCode, CategoryId, Barcode, ItemName, MRP,  
SalePrice,  Quantity, WholeSaleQuantity, 
IncludeGSTPercentage, GSTAmount, AmountExcludeGST, 
Is1Plus1Discount, ImageName)
values
(arg_GroupItemCode, arg_CategoryId, arg_Barcode, arg_ItemName,arg_MRP,  
arg_SalePrice,  arg_Quantity, arg_WholeSaleQuantity, 
arg_IncludeGSTPercentage, arg_GSTAmount, arg_AmountExcludeGST, 
arg_Is1Plus1Discount, arg_ImageName);
select arg_GroupItemCode as GroupId; 
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyInsertSale`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyInsertSale`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int,
arg_GSTAmount decimal(10,2),
arg_AmountExcludeGST decimal(10,2),
arg_ItemId int,
arg_IncludeGSTPercentage int,
arg_Is1Plus1Discount tinyint,
arg_ImageName varchar(50),
arg_Fontsize varchar(3),
arg_GroupCode int,
arg_Remark varchar(50),
arg_ExcAmount int,
arg_CategoryId int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertSale');
END;
START TRANSACTION;
insert into tbl_saledetail
(ItemId,InvoiceNo,GroupCode, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, 
DiscountPercentage, Quantity, Amount,IncludeGSTPercentage,GSTAmount,AmountExcludeGST
,Is1Plus1Discount,ImageName,Fontsize,Remark,ExchangeAmount,CategoryId)
values
(arg_ItemId,arg_InvoiceNumber,arg_GroupCode, arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, 
arg_DiscountPercentage, arg_Quantity, arg_Amount,arg_IncludeGSTPercentage,arg_GSTAmount,
arg_AmountExcludeGST,arg_Is1Plus1Discount,arg_ImageName,arg_Fontsize,arg_Remark,arg_ExcAmount,arg_CategoryId);
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyInsertSaleCreateInvoice`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyInsertSaleCreateInvoice`(  
arg_GroupCode int,
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int,
arg_GSTAmount decimal(10,2),
arg_AmountExcludeGST decimal(10,2),
arg_ItemId int,
arg_IncludeGSTPercentage int,
arg_Is1Plus1Discount tinyint,
arg_ImageName varchar(50),
arg_Fontsize varchar(3),
arg_Remark varchar(50),
arg_ExcAmount int,
arg_CategoryId int,
arg_CounterNo int
)
BEGIN
DECLARE VAR_INVOICENO NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyInsertSaleCreateInvoice');
END;
START TRANSACTION;
select InvoiceNo INTO VAR_INVOICENO from tbl_invoicenoreuse where usedstatus=0 limit 1 ;
if( VAR_INVOICENO is null)
then
insert into tbl_invoicenogeneration(Prifix) values('VLU');
select CONCAT('VLU',max(InvoiceNo)) INTO VAR_INVOICENO from tbl_invoicenogeneration;
else
update tbl_invoicenoreuse set usedstatus = 1 where InvoiceNo = VAR_INVOICENO;
end if;
insert into  tbl_sale 
(InvoiceNo, ExtraDiscount, CustomerName, PaymentBy, SGST, CGST, 
DueAmount,CounterId)
values
(VAR_INVOICENO, 0, VAR_INVOICENO, 'Cash', 0, 0,	0,arg_CounterNo);
insert into tbl_saledetail
(ItemId,InvoiceNo, GroupCode,Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, 
DiscountPercentage, Quantity, Amount,IncludeGSTPercentage,GSTAmount,AmountExcludeGST
,Is1Plus1Discount,ImageName,Fontsize,Remark,ExchangeAmount,CategoryId)
values
(arg_ItemId,VAR_INVOICENO, arg_GroupCode,arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, 
arg_DiscountPercentage, arg_Quantity, arg_Amount,arg_IncludeGSTPercentage,arg_GSTAmount,
arg_AmountExcludeGST,arg_Is1Plus1Discount,arg_ImageName,arg_Fontsize,arg_Remark,arg_ExcAmount,arg_CategoryId);
Select VAR_INVOICENO as InvoiceNumber;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyItemWiseExchangeRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyItemWiseExchangeRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_CategoryId int
)
BEGIN
if (arg_FDate <> '' and  arg_TDate <> '') 
then
select sum(Amount) as TotalSale,sum(TotalQuantity) as TotalQuantity,ItemName,CategoryName,CategoryId ,sum(ExcAmount) as ExcAmount  
from 
(
select sd.Amount,(sd.Quantity*sd.WholeSaleQuantity) as TotalQuantity,ItemName,inv.CategoryName,sd.CategoryId ,
sd.ExchangeAmount as ExcAmount
from tbl_saledetail sd 
inner join tbl_sale sa on sd.InvoiceNo=sa.invoiceNo and sa.IsDeleted=0
left join tbl_inventorycategory inv on sd.CategoryId = inv.CategoryId
where convert(sa.`Date`,date) between  arg_FDate  and  arg_TDate 
and ItemId < 0
and (sd.CategoryId = arg_CategoryId or arg_CategoryId = 0)
) as T group by ItemName,CategoryId
order by TotalQuantity desc;
end if;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyItemWiseSaleRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyItemWiseSaleRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_CategoryId int
)
BEGIN
	
	if (arg_FDate <> '' and  arg_TDate <> '') 
	then
        select sum(Amount) as TotalSale,sum(TotalQuantity) as TotalQuantity,ItemName,CategoryName,CategoryId ,sum(ExcAmount) as ExcAmount  
	from 
	(
	select sd.Amount,(sd.Quantity*sd.WholeSaleQuantity) as TotalQuantity,ItemName,inv.CategoryName,sd.CategoryId ,
        case when sa.TransactionType ='Exc Sale' then sa.ExcAmount else 0 end as ExcAmount
	from tbl_saledetail sd 
	inner join tbl_sale sa on sd.InvoiceNo=sa.invoiceNo and sa.IsDeleted=0
	left join tbl_inventorycategory inv on sd.CategoryId = inv.CategoryId
	where convert(sa.`Date`,date) between  arg_FDate  and  arg_TDate 
	 and ItemId >= 0
	 and (sd.CategoryId = arg_CategoryId or arg_CategoryId = 0)
	) as T group by ItemName,CategoryId
		order by TotalQuantity desc;
		
	end if;
	
					
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasySaleAddExhnageSubsetItems`;
DELIMITER |
CREATE PROCEDURE `Sp_EasySaleAddExhnageSubsetItems`(
arg_Invoice varchar(25)
)
BEGIN
select 	(-1 * inv.ItemId) as ItemId,inv.GroupCode, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, Quantity,  
'' as Description, IncludeGSTPercentage, GSTAmount, AmountExcludeGST, Is1Plus1Discount, 
ImageName, inv.Fontsize ,'' as GroupName,0 as Amount,'Exchange' as Remark,inv.Amount as ExcAmount,CategoryId
from  `tbl_saledetail_exchange` inv	
where inv.InvoiceNo =  arg_Invoice
order by id asc;  
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasySaleAndExcSaleRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasySaleAndExcSaleRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_UserID int,
arg_PaymentType varchar(50)
)
BEGIN
if (arg_FDate <> '' and  arg_TDate <> '') 
then
select PaymentDate,InvoiceNo, ExtraDiscount, CustomerName, CustomerMobile
, CustomerGST, PaymentBy, GST, SGST, CGST, 
PaidAmount, DueAmount, InvStatus, PayDate, IsDeleted, CounterId, UserId, ExcRef, ExcAmount, CashPay, 
CardPay, UPIPay, TransactionType  
, ifnull(T.UserId,0) as UserId,mc.DisplayName
,convert(arg_FDate,date) as FDate
,convert(arg_TDate,date) as TDate from
(
select 	`Date` as PaymentDate,InvoiceNo, ExtraDiscount, CustomerName, CustomerMobile
, CustomerGST, PaymentBy, GST, SGST, CGST, 
PaidAmount, DueAmount, `Status` as InvStatus, PayDate, IsDeleted, CounterId, UserId, ExcRef, ExcAmount, CashPay, 
CardPay, UPIPay, TransactionType 
from tbl_sale 
where isdeleted = 0 
and `status` <> 'Inprogress' 
and convert(`Date`,date) between  arg_FDate  and  arg_TDate		
and CounterId <> 0 and TransactionType in('Sale','Exc Sale') 
) as T inner join tbl_moduleaccess mc on T.UserId = mc.ID
where (UserId = arg_UserID or arg_UserID = 0)
and (PaymentBy = arg_PaymentType or arg_PaymentType ='')
or PaymentBy = 'Multi' 
order by PaymentDate desc;
end if;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasySaleRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasySaleRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_UserID int,
arg_PaymentType varchar(50),
arg_TransactionType varchar(50)
)
BEGIN
declare varMulti varchar(20);
set varMulti = 'Multi';
if(arg_PaymentType = 'Exc' or arg_TransactionType = 'Exc' )
then
set arg_TransactionType = 'Exc';
set arg_PaymentType = 'Exc';
set varMulti = 'Exc';
end if;
if (arg_FDate <> '' and  arg_TDate <> '') 
then
select PaymentDate,InvoiceNo, ExtraDiscount, CustomerName, CustomerMobile
, CustomerGST, PaymentBy, GST, SGST, CGST, 
PaidAmount, DueAmount, InvStatus, PayDate, IsDeleted, CounterId, UserId, ExcRef, ExcAmount, CashPay, 
CardPay, UPIPay, TransactionType  
, ifnull(T.UserId,0) as UserId,mc.DisplayName
,convert(arg_FDate,date) as FDate
,convert(arg_TDate,date) as TDate from
(
select 	`Date` as PaymentDate,InvoiceNo, ExtraDiscount, CustomerName, CustomerMobile
, CustomerGST, PaymentBy, GST, SGST, CGST, 
PaidAmount, DueAmount, `Status` as InvStatus, PayDate, IsDeleted, CounterId, UserId, ExcRef, ExcAmount, CashPay, 
CardPay, UPIPay, TransactionType 
from tbl_sale 
where isdeleted = 0 
and `status` <> 'Inprogress' 
and convert(`Date`,date) between  arg_FDate  and  arg_TDate		
and CounterId <> 0 and (TransactionType = arg_TransactionType or arg_TransactionType = '') 
) as T inner join tbl_moduleaccess mc on T.UserId = mc.ID
where (UserId = arg_UserID or arg_UserID = 0)
and (PaymentBy = arg_PaymentType or arg_PaymentType ='')
or PaymentBy = varMulti 
order by InvoiceNo desc;
end if;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyUpdateExchangeNumber`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyUpdateExchangeNumber`(
arg_InvoiceNo VARCHAR(50),
arg_ExcRef VARCHAR(50)
)
BEGIN
declare varSaleID int;
select ID into varSaleID from tbl_sale where  InvoiceNo = arg_InvoiceNo limit 1;
update tbl_sale set ExcRef  = arg_ExcRef   where  ID = varSaleID;
select ifnull(varSaleID,0) as SaleId;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyUpdateItem`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyUpdateItem`(  
arg_ItemId int,
arg_GroupItemCode int,
arg_ImageName NVARCHAR(50),
arg_LoginUser NVARCHAR(100),
arg_CategoryId int,
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int, 
arg_SalePrice int,
arg_Quantity int,
arg_WholeSaleQuantity int,
arg_IncludeGSTPercentage int,
arg_GSTAmount decimal(10,2),
arg_AmountExcludeGST decimal(10,2),
arg_Is1Plus1Discount int,
arg_IsMain int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyUpdateItem');
END;
START TRANSACTION;
if( arg_IsMain = 1 )
then
update tbl_easygroupitem set ImageURL = arg_ImageName where GroupCode = arg_GroupItemCode;
end if;
update tbl_inventory set  CategoryId = arg_CategoryId, Barcode = arg_Barcode, ItemName = arg_ItemName
,MRP = arg_MRP, SalePrice = arg_SalePrice, WholeSaleQuantity = arg_WholeSaleQuantity, 
IncludeGSTPercentage = arg_IncludeGSTPercentage, GSTAmount = arg_GSTAmount, AmountExcludeGST = arg_AmountExcludeGST
,ImageName = arg_ImageName where Id = arg_ItemId and GroupCode = arg_GroupItemCode;
select arg_GroupItemCode as GroupId; 
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyUpdateSale`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyUpdateSale`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int,
arg_GSTAmount decimal,
arg_AmountExcludeGST decimal,
arg_ItemId int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyUpdateSale');
END;
START TRANSACTION;
update tbl_saledetail set 
Discount = arg_Discount, 
Quantity =arg_Quantity, Amount = arg_Amount,GSTAmount = arg_GSTAmount ,AmountExcludeGST = arg_AmountExcludeGST 
where ItemId = arg_ItemId and InvoiceNo = arg_InvoiceNumber;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyUpdateSaleDetail`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyUpdateSaleDetail`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_ExtraDiscount int,
arg_CustomerName NVARCHAR(50),
arg_PaymentBy NVARCHAR(20),	 
arg_GST decimal(10,2), 
arg_DueAmount int,
arg_Status NVARCHAR(50),
arg_PaidAmount int,
arg_CustomerMobile NVARCHAR(50),
arg_CustomerGST NVARCHAR(50),
arg_LoginUser  NVARCHAR(50),
arg_CounterId int,
arg_UserId int,
arg_ExcRef varchar(50),
arg_ExcAmount int,
arg_CashPay int,
arg_CardPay int,
arg_UPIPay int,
arg_TransType varchar(50)
)
BEGIN
declare varSGST decimal(10,3);
declare varnum varchar(20);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_EasyUpdateSaleDetail');
END;
START TRANSACTION;
set varSGST = arg_GST / 2;
update tbl_sale set 
ExtraDiscount = arg_ExtraDiscount, 
CustomerName = arg_CustomerName, PaymentBy = arg_PaymentBy,
GST = arg_GST, DueAmount = arg_DueAmount,`Status` = arg_Status,
PaidAmount = arg_PaidAmount,CustomerMobile= arg_CustomerMobile, CustomerGST = arg_CustomerGST,
CounterId = arg_CounterId,UserId=arg_UserId, ExcRef=arg_ExcRef, ExcAmount=arg_ExcAmount, 
CashPay=arg_CashPay, CardPay=arg_CardPay ,UPIPay=arg_UPIPay, TransactionType=arg_TransType, IsDeleted=0,
SGST = varSGST, CGST = varSGST
where InvoiceNo = arg_InvoiceNumber;
insert into `tbl_salehistory` 
(LoginUser, Customer, TotalBill, PaidAmount, DueAmount, DiscountOnBill, 
InvoiceNumner, Date)
values
(arg_LoginUser, arg_CustomerName, (arg_ExtraDiscount+arg_DueAmount+arg_PaidAmount), arg_PaidAmount, arg_DueAmount, arg_ExtraDiscount, 
arg_InvoiceNumber, now());
select CustomerPhone into varnum from tbl_customers where CustomerPhone = arg_CustomerMobile limit 1;
if(varnum is null)
then
insert into tbl_customers(CustomerName,CustomerPhone) values(arg_CustomerName,arg_CustomerMobile);
end if;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyUserSaleRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyUserSaleRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_UserID int,
arg_PaymentType varchar(50),
arg_TransactionType varchar(50)
)
BEGIN
declare varMulti varchar(20);
set varMulti = 'Multi';
if(arg_PaymentType = 'Exc' or arg_TransactionType = 'Exc' )
then
set arg_TransactionType = 'Exc';
set arg_PaymentType = 'Exc';
set varMulti = 'Exc';
end if;
if (arg_FDate <> '' and  arg_TDate <> '') 
then
select case when arg_PaymentType = 'Cash' then sum(T.CashPay) 
when arg_PaymentType = 'Card' then sum(T.CardPay)
when arg_PaymentType = 'UPI' then sum(T.UPIPay)
else ifnull(sum(T.PaidAmount),0) end as CounterSale
, ifnull(T.UserId,0) as UserId,mc.DisplayName,Sum(ifnull(ExcAmount,0)) as ExcAmount
,convert(arg_FDate,date) as FDate
,convert(arg_TDate,date) as TDate from
(
select 	convert(`Date`,date) as PaymentDate,PaymentBy,PaidAmount, `Status` as InvStatus,
PayDate, IsDeleted, CounterId, UserId, ExcRef, ExcAmount, CashPay, 
CardPay, UPIPay, TransactionType 
from tbl_sale 
where isdeleted = 0 
and `status` <> 'Inprogress' 
and convert(`Date`,date) between  arg_FDate  and  arg_TDate		
and CounterId <> 0 and (TransactionType = arg_TransactionType or arg_TransactionType = '') 
) as T inner join tbl_moduleaccess mc on T.UserId = mc.ID
where (UserId = arg_UserID or arg_UserID = 0)
and (PaymentBy = arg_PaymentType or arg_PaymentType ='')
or PaymentBy = varMulti 
group by UserId order by UserId asc;
end if;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_EasyUserWiseSaleRecord`;
DELIMITER |
CREATE PROCEDURE `Sp_EasyUserWiseSaleRecord`(
arg_FDate varchar(50),
arg_TDate varchar(50),
arg_UserID int,
arg_PaymentType varchar(50),
arg_TransactionType varchar(50)
)
BEGIN
declare varMulti varchar(20);
set varMulti = 'Multi';
if(arg_PaymentType = 'Exc' or arg_TransactionType = 'Exc' )
then
set arg_TransactionType = 'Exc';
set arg_PaymentType = 'Exc';
set varMulti = 'Exc';
end if;
if (arg_FDate <> '' and  arg_TDate <> '') 
then
select sum(bycash) as CashPay ,sum(bycard) as CardPay, sum(byupi) as UPIPay,
(sum(bycash) +sum(bycard)+ sum(byupi)) as CounterSale ,userid  
,convert(arg_FDate,date) as FDate
,convert(arg_TDate,date) as TDate
from
(
select sum(cashpayment) as bycash ,sum(cardpayment) as bycard ,sum(upipayment) as byupi ,counterid,userid 
,ifnull(mc.DisplayName,'') as DisplayName,TransactionType
from vtbl_sale_gb_cputd 
left join tbl_moduleaccess mc on UserId = mc.ID
where  SaleDate between  arg_FDate  and  arg_TDate
and (UserId = arg_UserID or arg_UserID = 0)
and (PaymentBy = arg_PaymentType or arg_PaymentType ='')
or PaymentBy = varMulti
group by counterid,userid,TransactionType
) as T  where (TransactionType = arg_TransactionType or arg_TransactionType = '')
group by userid;
end if;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GenRandom`;
DELIMITER |
CREATE PROCEDURE `Sp_GenRandom`()
BEGIN
declare var_counter int;
SET var_counter = 100000;
WHILE(var_counter <= 199991)
DO   
insert into tbl_number(Number,PreFix) values(var_counter,'');	
SET var_counter = var_counter + 1;
END WHILE;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetAppModuleList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetAppModuleList`( 
arg_GroupId int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_GetAppModuleList');
END;
START TRANSACTION;
select am.GroupID ,am.ModuleID, GroupName,ModuleName,Access ,Sequence,Tcolor,Bcolor,MImage
from vtbl_module_access am
inner join tbl_usergroup ug on am.groupid= ug.groupid 
where am.GroupID = arg_GroupId  and am.IsActive = 1
order by Sequence asc;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetAppSetup`;
DELIMITER |
CREATE PROCEDURE `Sp_GetAppSetup`()
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_GetAppSetup');
END;
START TRANSACTION;
select 	ID, VariableKey, VariableDesc, VariableValue 
from `tbl_appsetup`  ;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetBankDetail`;
DELIMITER |
CREATE PROCEDURE `Sp_GetBankDetail`(
)
BEGIN
select BankName, AccountNo, IFSC, AccHolderName, BankAddress,UPIID 
from 
`tbl_bankdetail` limit 1;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetCustomer`;
DELIMITER |
CREATE PROCEDURE `Sp_GetCustomer`(
arg_Phone varchar(15)
)
BEGIN
select 	CustomerId, CustomerName, CustomerPhone 
from `tbl_customers` where CustomerPhone = arg_Phone limit 1;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetDealerNameList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetDealerNameList`(
)
BEGIN
DECLARE paidamount int;
select dl.ID, Name, Mobile, Address, PGSTNo ,sum(od.BalanceAmount)  as Balance
from tbl_dealer dl 
inner join tbl_order od on od.DealerId = dl.ID	 
group by dl.ID, Name, Mobile, Address, PGSTNo
order by Name asc;	
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetExchangeItemByBarcode`;
DELIMITER |
CREATE PROCEDURE `Sp_GetExchangeItemByBarcode`(
arg_Barcode NVARCHAR(50)
)
BEGIN
select 	InvoiceNo, Barcode,'' as ExBarcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, Quantity,Amount
from 
tbl_saledetail  where Barcode = arg_Barcode ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetHRFInstructionList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetHRFInstructionList`(
)
BEGIN
select 	HRF_Code, HRF_Name ,'' as HRF_Value,Show_Hide
from 
`tbl_hrf_instruction` ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetHRFPrintingDataImportedList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetHRFPrintingDataImportedList`(
)
BEGIN
select ID,HRF_1,HRF_2,HRF_3,HRF_4, HRF_5, HRF_6, HRF_7, HRF_8,HRF_9,HRF_10,Print_Quantity  
from tbl_hrf_printing_data where barcode <> null order by id desc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetHRFPrintingDataList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetHRFPrintingDataList`(
)
BEGIN
select ID,HRF_1,HRF_2,HRF_3,HRF_4, HRF_5, HRF_6, HRF_7, HRF_8,HRF_9,HRF_10, HRF_11, HRF_12, HRF_13, HRF_14, HRF_15,Print_Quantity  
from tbl_hrf_printing_data where barcode ='' order by id desc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetHRFPrintingDataListHead`;
DELIMITER |
CREATE PROCEDURE `Sp_GetHRFPrintingDataListHead`(
)
BEGIN
SELECT 9999 as ID, 
cast(GROUP_CONCAT( HRF_1 ) as char(50)) as HRF_1 ,
cast(GROUP_CONCAT( HRF_2 ) as char(50)) as HRF_2 ,
cast(GROUP_CONCAT( HRF_3 ) as char(50)) as HRF_3 ,
cast(GROUP_CONCAT( HRF_4 ) as char(50)) as HRF_4 ,
cast(GROUP_CONCAT( HRF_5 ) as char(50)) as HRF_5 ,
cast(GROUP_CONCAT( HRF_6 ) as char(50)) as HRF_6 ,
cast(GROUP_CONCAT( HRF_7 ) as char(50)) as HRF_7 ,
cast(GROUP_CONCAT( HRF_8 ) as char(50)) as HRF_8 ,
cast(GROUP_CONCAT( HRF_9 ) as char(50)) as HRF_9 ,
cast(GROUP_CONCAT( HRF_10 ) as char(50)) as HRF_10,0 as Print_Quantity 
FROM vtbl_hrf_instructionexten;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetHRFPrintingImportDataList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetHRFPrintingImportDataList`(
)
BEGIN
select ID,Barcode,HRF_1,HRF_2,HRF_3,HRF_4, HRF_5, HRF_6, HRF_7, HRF_8,HRF_9,HRF_10,Print_Quantity  
from tbl_hrf_printing_data where barcode <> '' order by id desc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetInprogressInventory`;
DELIMITER |
CREATE PROCEDURE `Sp_GetInprogressInventory`()
BEGIN
select 	Id, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, Quantity, Expiry 
from 
tbl_inventory_inprogress; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetInprogressInventoryMaster`;
DELIMITER |
CREATE PROCEDURE `Sp_GetInprogressInventoryMaster`()
BEGIN
select 	iv.Id, iv.Barcode, iv.ItemName, iv.MRP, iv.BuyPrice, iv.SalePrice, iv.Discount, iv.DiscountPercentage
, iv.Quantity, iv.Expiry ,iv.Description
from 
tbl_inventory_inprogress iv where iv.quantity=0;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetInprogressInventoryUniqueProduct`;
DELIMITER |
CREATE PROCEDURE `Sp_GetInprogressInventoryUniqueProduct`()
BEGIN
select 	iv.Id, iv.Barcode, iv.ItemName, iv.MRP, iv.BuyPrice, iv.SalePrice, iv.Discount, iv.DiscountPercentage
, iv.Quantity, iv.Expiry ,iv.Description
from 
tbl_inventory_inprogress iv where  iv.quantity <> 0;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetInprogressInvoiceNoList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetInprogressInvoiceNoList`(
arg_CounterNo int
)
BEGIN
select 	distinct sa.invoiceNo
from tbl_saledetail sd
inner join tbl_sale sa on sd.InvoiceNo = sa.InvoiceNo 
where sa.IsDeleted = 0 and sa.Status = 'Inprogress' and CounterId = arg_CounterNo;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetInprogressQuotationNoList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetInprogressQuotationNoList`(
)
BEGIN
select 	 sa.invoiceNo ,sa.CustomerName, sa.CustomerMobile,sum(amount) as Amount,sa.Date,sa.ExtraDiscount 
from tbl_saledetail_quotation sd
inner join tbl_sale_quotation sa on sd.InvoiceNo = sa.InvoiceNo 
where sa.IsDeleted = 0 and sa.Status in( 'Inprogress','Printed') and sa.date > (curdate()- interval 60 day )
group by sa.invoiceNo ,sa.CustomerName, sa.CustomerMobile,sa.Date;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetInprogressQuotationOneByOne`;
DELIMITER |
CREATE PROCEDURE `Sp_GetInprogressQuotationOneByOne`(
arg_InvoiceNo NVARCHAR(50)
)
BEGIN
select  sd.invoiceNo, sd.Barcode, sd.ItemName, sd.MRP, sd.BuyPrice, sd.SalePrice, sd.Discount, sd.DiscountPercentage, sd.Quantity, sd.Amount,
sa.CustomerName, sa.Date, 
CASE ifnull(mi.barcode,'')
WHEN '' THEN false	     
ELSE true
END as 'IsMasterItem' ,sa.Status,sa.ExtraDiscount ,sa.CustomerMobile
from tbl_saledetail_quotation sd
inner join tbl_sale_quotation sa on sd.InvoiceNo = sa.InvoiceNo 
left join tbl_inventorymasterunit mi on sd.ItemName = mi.ItemName
where sa.IsDeleted = 0  and sa.InvoiceNo = arg_InvoiceNo ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetInprogressSaleOneByOne`;
DELIMITER |
CREATE PROCEDURE `Sp_GetInprogressSaleOneByOne`(
arg_InvoiceNo NVARCHAR(50)
)
BEGIN
	-- declare varinvoice NVARCHAR(50);
	-- select InvoiceNo into varinvoice from tbl_sale where Status = 'Inprogress' and IsDeleted = 0 limit 1;
	select  sd.invoiceNo, sd.Barcode, sd.ItemName, sd.MRP, sd.BuyPrice, sd.SalePrice, sd.Discount, sd.DiscountPercentage
	, sd.Quantity, sd.Amount,
	sa.CustomerName, sa.Date, 
	CASE ifnull(mi.barcode,'')
	      WHEN '' THEN false	     
	      ELSE true
	  END as 'IsMasterItem' ,GroupCode, IncludeGSTPercentage, GSTAmount, AmountExcludeGST, Is1Plus1Discount,ImageName
	, Fontsize,sd.ItemId,ifnull(sa.ExcRef,'') as ExchangeNumber,sd.ExchangeAmount,sd.Remark,sa.`Date` as SaleDate
	from tbl_saledetail sd
	inner join tbl_sale sa on sd.InvoiceNo = sa.InvoiceNo 
	left join tbl_inventorymasterunit mi on sd.barcode = mi.barcode
	where sa.IsDeleted = 0 and sa.Status = 'Inprogress' and sa.InvoiceNo = arg_InvoiceNo ;
	
	
	
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetInventorListForDiscount`;
DELIMITER |
CREATE PROCEDURE `Sp_GetInventorListForDiscount`(
arg_ItemName  NVARCHAR(100)
)
BEGIN
select 	Id, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, Quantity, Expiry 
from 
tbl_inventory where ItemName= arg_ItemName; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetInventorMasterUnitListForQuantityEdit`;
DELIMITER |
CREATE PROCEDURE `Sp_GetInventorMasterUnitListForQuantityEdit`(
arg_ItemName  NVARCHAR(100)
)
BEGIN
select 	Id, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, Quantity, Expiry 
from 
tbl_inventorymasterunit where ItemName= arg_ItemName; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetItemByBarcode`;
DELIMITER |
CREATE PROCEDURE `Sp_GetItemByBarcode`(
arg_Barcode NVARCHAR(50)
)
BEGIN
if(select barcode from tbl_inventorymasterunit where Barcode = arg_Barcode)
then
select 	 iv.Id, iv.Barcode, iv.ItemName, iv.MRP, iv.BuyPrice, iv.SalePrice, iv.Discount, iv.DiscountPercentage, iv.Quantity, iv.Expiry,iv.Description
, true as IsMasterItem
from 
tbl_inventory iv where iv.Barcode = arg_Barcode;
else
select 	 iv.Id, iv.Barcode, iv.ItemName, iv.MRP, iv.BuyPrice, iv.SalePrice, iv.Discount, iv.DiscountPercentage, iv.Quantity, iv.Expiry,iv.Description
,false as IsMasterItem
from 
tbl_inventory iv 
left join vtbl_saleinprogress ds on iv.barcode=ds.barcode 
where iv.Barcode = arg_Barcode  and ds.barcode is null;
end if;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetModule`;
DELIMITER |
CREATE PROCEDURE `Sp_GetModule`( 
arg_username VARCHAR(50),        
arg_password VARCHAR(50),
arg_key VARCHAR(50)
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_GetModule');
END;
START TRANSACTION;
select DisplayName,Username,UserPassword,GroupId,GroupName,ModuleName,ModuleCode,Access,UserID from
(
select DisplayName, Username,userpass as UserPassword,
ug.GroupId,ug.GroupName,am.ModuleName,am.ModuleCode,am.Access,ma.ID as UserID
from tbl_moduleaccess ma
inner join tbl_usergroup ug on ug.groupid=ma.groupid and ma.IsActive
inner join vtbl_module_access am on am.groupid=ug.groupid and am.IsActive = 1
) as T where UserPassword=arg_password and username=arg_username;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetMonhList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetMonhList`(
)
BEGIN
select MonthText from tbl_months;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetNumnersToPrint`;
DELIMITER |
CREATE PROCEDURE `Sp_GetNumnersToPrint`(
arg_PrintCount int
)
BEGIN
select  Number, PreFix, `Status` 
from 
`tbl_number` where `status` = 1 limit arg_PrintCount;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetPendingInvoiceByDealer`;
DELIMITER |
CREATE PROCEDURE `Sp_GetPendingInvoiceByDealer`(
arg_DealerId int
)
BEGIN
select  d.ID as DealerId, d.Name as DealerName,o.OrderNo as InvoiceNo,o.OrderDate,o.OrderAmount as `BillAmount`,
o.PaidAmount,o.BalanceAmount
from `tbl_dealer` d
inner join tbl_order o on d.ID=o.dealerid
where o.DealerId=arg_DealerId and o.BalanceAmount > 0 ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetPendingSaleList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetPendingSaleList`(
arg_inv NVARCHAR(50),
arg_cst NVARCHAR(50)
)
BEGIN
select  sa.Status,InvoiceNo,ExtraDiscount,CustomerName,CustomerMobile,PaidAmount,DueAmount,`date` as SaleDate,PaymentBy,GST
,CustomerMobile,CustomerGST
from  tbl_sale sa 
where sa.IsDeleted = 0 and sa.Status in('Full Payment Pending','Partial Pending') 
and (InvoiceNo like concat('%',arg_inv,'%') and CustomerName like concat('%',arg_cst,'%'));
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetPrintedInventory`;
DELIMITER |
CREATE PROCEDURE `Sp_GetPrintedInventory`()
BEGIN
select 	Id, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, Quantity, Expiry ,ScanStatus
from 
tbl_inventory_printed; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetPrintedNumber`;
DELIMITER |
CREATE PROCEDURE `Sp_GetPrintedNumber`(
arg_Source varchar(20)
)
BEGIN
select 	Id, Barcode, ItemName, MRP,  SalePrice, Discount, DiscountPercentage, Quantity, ScanStatus
from 
tbl_hrf_printed_data where source = arg_Source; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetPrinterName`;
DELIMITER |
CREATE PROCEDURE `Sp_GetPrinterName`(
arg_Type varchar(50),
arg_CounterId int
)
BEGIN
select 	ID, CounterId, PrinterType, Name 
from 
`tbl_printers` where CounterId = arg_CounterId and PrinterType = arg_Type;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetPurchaseInvoiceList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetPurchaseInvoiceList`(
arg_DealerId int
)
BEGIN
select o.ID as OrderId, d.Name as DealerName,od.OrderNo as InvoiceNo,PGSTNo,o.tax as GST_Amount,o.OrderAmount as `Total BillAmount`
,od.ItemName,od.Quantity,od.Rate,od.RateAfterTax
,od.Amount as `Item Amount`,od.SalePrice,od.MRP, Mobile, MobileAlt, Address
from `tbl_dealer` d
inner join tbl_order o on d.ID=o.dealerid
inner join tbl_orderdetail od on od.OrderId= o.ID
where o.dealerid = arg_DealerId
order by o.ID desc;	
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetPurchasePaidList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetPurchasePaidList`(
arg_DealerId int
)
BEGIN
select  Name as DealerName, PaymentDate, PaymentAmount, OrderNo ,Description
from `tbl_dealer_paid` dp
inner join tbl_dealer d on dp.dealerid=d.id
where dp.dealerid= arg_DealerId
order by dp.ID desc limit 100;	
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetSaleByInvoiceNo`;
DELIMITER |
CREATE PROCEDURE `Sp_GetSaleByInvoiceNo`(
arg_InvoiceNo NVARCHAR(50)
)
BEGIN
select  sd.invoiceNo, sd.Barcode, sd.ItemName, sd.MRP, sd.BuyPrice, sd.SalePrice, sd.Discount, sd.DiscountPercentage, sd.Quantity, sd.Amount,
sa.CustomerName, sa.Date, 
CASE ifnull(mi.barcode,'')
WHEN '' THEN false	     
ELSE true
END as 'IsMasterItem' , sa.CustomerMobile,sa.PaidAmount
from tbl_saledetail sd
inner join tbl_sale sa on sd.InvoiceNo = sa.InvoiceNo 
left join tbl_inventorymasterunit mi on sd.barcode = mi.barcode
where sa.IsDeleted = 0 and sa.Status <> 'Inprogress' and sa.InvoiceNo = arg_InvoiceNo ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetSerialPortSettingsList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetSerialPortSettingsList`(
arg_CounterId int
)
BEGIN
select Id, DataBits, ComPort, Comm_Type, CustomName, Flow, Parity, PrinterIp, PrinterPort, DeviceNumber, BaudRate, StopBits
from 
tbl_scannersettings where DeviceNumber='Scanner_1' and CounterId= arg_CounterId  ; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetSerialPortSettingsPrinter`;
DELIMITER |
CREATE PROCEDURE `Sp_GetSerialPortSettingsPrinter`(
arg_CounterId int
)
BEGIN
select Id, DataBits, ComPort, Comm_Type, CustomName as SerialName, Flow, Parity, PrinterIp, PrinterPort, DeviceNumber, BaudRate, StopBits
from 
tbl_scannersettings where DeviceNumber='Zebra_Printer_1' and CounterId= arg_CounterId  ; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetUserList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetUserList`()
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_GetUserList');
END;
START TRANSACTION;
select ma.ID as UserID,DisplayName, Username,userpass as UserPassword,
ug.GroupName,ug.GroupID
from tbl_moduleaccess ma
inner join tbl_usergroup ug on ug.groupid=ma.groupid ;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetUserNameList`;
DELIMITER |
CREATE PROCEDURE `Sp_GetUserNameList`()
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_GetUserNameList');
END;
START TRANSACTION;
select DisplayName, Username
from tbl_moduleaccess  where IsActive = 1;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GetUserRolelist`;
DELIMITER |
CREATE PROCEDURE `Sp_GetUserRolelist`(
arg_RoleId int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_GetUserRolelist');
END;
START TRANSACTION;
if(arg_RoleId <> 1)
then
select GroupID, GroupName
from tbl_usergroup where GroupID <> 1;
else
select GroupID, GroupName
from tbl_usergroup;
end if;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Get_hrf_printed_data_list`;
DELIMITER |
CREATE PROCEDURE `Sp_Get_hrf_printed_data_list`(
)
BEGIN
	
	select ID,Barcode, ItemName as HRF_1 , MRP as HRF_2 ,SalePrice as HRF_3  ,HRF_4, HRF_5, HRF_6, HRF_7, HRF_8,HRF_9,HRF_10,Quantity as Print_Quantity  
	from tbl_hrf_printed_data_list where barcode <> '' order by id desc;
	
	
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_GSTDetail`;
DELIMITER |
CREATE PROCEDURE `Sp_GSTDetail`()
BEGIN
select GSTPercentage, CGSTPercentage, SGSTPercentage ,GSTNumber
from 
`tbl_gstdetail` ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertDealer`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertDealer`( 
arg_Name NVARCHAR(50),        
arg_Mobile NVARCHAR(20),
arg_Address NVARCHAR(200),
arg_PGSTNo NVARCHAR(50),
arg_MobileAlt NVARCHAR(20)
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertDealer');
END;
START TRANSACTION;
insert into `tbl_dealer` 
(Name, Mobile,MobileAlt, Address,PGSTNo , IsActive)
values
(arg_Name, arg_Mobile,arg_MobileAlt, arg_Address,arg_PGSTNo, 1);
select LAST_INSERT_ID() as DealerId;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertHRFPRintedData`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertHRFPRintedData`(
arg_Barcode varchar(50),
arg_ItemName varchar(50),
arg_MRP varchar(50),
arg_SalePrice varchar(50),
arg_Discount varchar(50),
arg_DiscountPercentage varchar(50),
arg_Quantity varchar(50),
arg_HRF_4 varchar(50),
arg_HRF_5 varchar(50),
arg_HRF_6 varchar(50),
arg_HRF_7 varchar(50),
arg_HRF_8 varchar(50),
arg_HRF_9 varchar(50),
arg_HRF_10 varchar(50),
arg_Source varchar(50)
)
BEGIN
insert into `tbl_hrf_printed_data` 
(Barcode, ItemName, MRP, SalePrice, Discount, DiscountPercentage, 
Quantity, HRF_4, HRF_5, HRF_6, HRF_7, HRF_8, HRF_9, HRF_10, Source)
values
(arg_Barcode, arg_ItemName, arg_MRP, arg_SalePrice, arg_Discount, arg_DiscountPercentage, 
arg_Quantity, HRF_4, HRF_5, HRF_6, HRF_7, HRF_8, HRF_9, HRF_10,	arg_Source);
select LAST_INSERT_ID() as ppid;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertHRFPritingData`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertHRFPritingData`(
arg_Barcode varchar(50),
arg_HRF_1 varchar(50),
arg_HRF_2 varchar(50),
arg_HRF_3 varchar(50),
arg_HRF_4 varchar(50),
arg_HRF_5 varchar(50),
arg_HRF_6 varchar(50),
arg_HRF_7 varchar(50),
arg_HRF_8 varchar(50),
arg_HRF_9 varchar(50),
arg_HRF_10 varchar(50),
arg_HRF_11 varchar(50),
arg_HRF_12 varchar(50),
arg_HRF_13 varchar(50),
arg_HRF_14 varchar(50),
arg_HRF_15 varchar(50),
arg_Print_Quantity int
)
BEGIN
insert into `tbl_hrf_printing_data` 
( Barcode,HRF_1, HRF_2, HRF_3, HRF_4, HRF_5, HRF_6, HRF_7, HRF_8, HRF_9, 
HRF_10, HRF_11, HRF_12, HRF_13, HRF_14, HRF_15,Print_Quantity)
values
(arg_Barcode, arg_HRF_1, arg_HRF_2,arg_HRF_3, arg_HRF_4, arg_HRF_5, arg_HRF_6, arg_HRF_7, arg_HRF_8, arg_HRF_9, 
arg_HRF_10, arg_HRF_11, arg_HRF_12, arg_HRF_13, arg_HRF_14, arg_HRF_15, arg_Print_Quantity);
select LAST_INSERT_ID() as ppid;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertInventorIprogressAndInventory`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertInventorIprogressAndInventory`( 
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Expiry NVARCHAR(50),
arg_Description NVARCHAR(100)
)
BEGIN
DECLARE var_barcodecheck varchar(100);
DECLARE var_name varchar(100);
DECLARE var_Masterbarcodecheck varchar(100);
DECLARE var_mastername varchar(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertInventorIprogressAndInventory');
END;
START TRANSACTION;
set var_Masterbarcodecheck ='';
set var_mastername ='';
set var_barcodecheck ='';
select barcode into var_barcodecheck from tbl_inventory where barcode= arg_Barcode limit 1;
IF (var_barcodecheck = '')
then
insert into `tbl_inventory_inprogress` 
(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, Expiry,Description)
values
(arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, arg_DiscountPercentage, 
arg_Quantity, arg_Expiry,arg_Description);
insert into `tbl_inventory` 
(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, Expiry,Description)
values
(arg_Barcode, arg_ItemName, arg_MRP,arg_BuyPrice, arg_SalePrice, arg_Discount, arg_DiscountPercentage, 
arg_Quantity, arg_Expiry,arg_Description);
SELECT '0' AS Duplicate,arg_ItemName as ItemName ;
ELSE
select barcode into var_Masterbarcodecheck from tbl_inventorymasterunit where barcode= arg_Barcode limit 1;
select ItemName into var_mastername from tbl_inventorymasterunit where barcode= arg_Barcode limit 1;
IF (var_Masterbarcodecheck = '')
then
SELECT '1' AS Duplicate, arg_ItemName as ItemName; 
else
SELECT '9' AS Duplicate , var_mastername as ItemName; 
end if;
END IF;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertInventorPrinted`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertInventorPrinted`( 
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Expiry NVARCHAR(50)
)
BEGIN
DECLARE var_barcodecheck varchar(100);
DECLARE var_name varchar(100);
declare var_POID int;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertInventorPrinted');
END;
START TRANSACTION;
set var_barcodecheck ='';
select barcode into var_barcodecheck from tbl_inventory where barcode= arg_Barcode limit 1;
IF (var_barcodecheck = '')
then
insert into `tbl_inventory_printed` 
(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, Expiry)
values
(arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, arg_DiscountPercentage, 
arg_Quantity, arg_Expiry);
select ItemName into var_name from tbl_namemaster where ItemName = arg_ItemName limit 1;
if(var_name is null)
then
insert into tbl_namemaster(ItemName) values(arg_ItemName);
end if;
SELECT '0' AS Duplicate;
ELSE
SELECT '1' AS Duplicate;
END IF;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertInventoryAddHistory`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertInventoryAddHistory`( 
arg_UserName NVARCHAR(50),        
arg_ItemName  NVARCHAR(100),
arg_Comment NVARCHAR(100),
arg_IsAdd int 
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertInventoryAddHistory');
END;
START TRANSACTION;
if( arg_IsAdd = 1) then
insert into `tbl_inventoryaddedhistory` 
(UserName, AddedTime, ItemName, AddedComment)
values
( arg_UserName, now(), arg_ItemName, arg_Comment);
else
insert into `tbl_inventoryaddedhistory` 
(UserName, AddedTime, ItemName, DiscountComment)
values
( arg_UserName, now(), arg_ItemName, arg_Comment);
end if;
select LAST_INSERT_ID() as ID;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertInventoryFromPrint`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertInventoryFromPrint`( 
	 arg_Barcode NVARCHAR(50),
	 arg_ItemName NVARCHAR(50),
         arg_MRP int,	 
	 arg_BuyPrice int, 
	 arg_SalePrice int,
	 arg_Discount int,
	 arg_DiscountPercentage int,
	 arg_Quantity int,
arg_Expiry NVARCHAR(50)
	)
BEGIN
 DECLARE var_barcodecheck varchar(100);
 DECLARE var_name varchar(100);
 DECLARE var_Masterbarcodecheck varchar(100);
 DECLARE var_mastername varchar(100);
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
	 ROLLBACK;
	Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
	 values(null,null,'Error ocured', null, null,null,'Sp_InsertInventorIprogressAndInventory');
	
          
    END;
	
   START TRANSACTION;
	 
         set var_Masterbarcodecheck ='';
         set var_mastername ='';
         set var_barcodecheck ='';
         select barcode into var_barcodecheck from tbl_inventory where barcode= arg_Barcode limit 1;
        
	IF (var_barcodecheck = '')
	then
		
		insert into `tbl_inventory` 
		(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
		Quantity, Expiry)
		values
		(arg_Barcode, arg_ItemName, arg_MRP,arg_BuyPrice, arg_SalePrice, arg_Discount, arg_DiscountPercentage, 
		arg_Quantity, arg_Expiry);
		insert into `tbl_hrf_printed_data_list` 
		(Barcode, ItemName, MRP, SalePrice, Discount, DiscountPercentage, 
		Quantity, HRF_4, HRF_5, HRF_6, HRF_7, HRF_8, HRF_9, HRF_10, HRF_11, 
		HRF_12, HRF_13, HRF_14, HRF_15, ScanStatus, Source)
		select Barcode, ItemName, MRP, SalePrice, Discount, DiscountPercentage, 
		Quantity, HRF_4, HRF_5, HRF_6, HRF_7, HRF_8, HRF_9, HRF_10, HRF_11, 
		HRF_12, HRF_13, HRF_14, HRF_15, ScanStatus, Source from `tbl_hrf_printed_data` where barcode = arg_Barcode;
		delete from tbl_hrf_printed_data where Barcode = arg_Barcode;
		if ( arg_Quantity > 1)
		then
			insert into `tbl_inventoryMasterUnit` 
				(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
				Quantity, Expiry)
				values
				(arg_Barcode, arg_ItemName, arg_MRP,arg_BuyPrice, arg_SalePrice, arg_Discount, arg_DiscountPercentage, 
				arg_Quantity, arg_Expiry);
		end if;
		
		SELECT '0' AS Duplicate,arg_ItemName as ItemName ;
	ELSE
		
		select barcode into var_Masterbarcodecheck from tbl_inventorymasterunit where barcode= arg_Barcode limit 1;
		select ItemName into var_mastername from tbl_inventorymasterunit where barcode= arg_Barcode limit 1;
		IF (var_Masterbarcodecheck = '')
		then
			SELECT '1' AS Duplicate, arg_ItemName as ItemName; -- item duplicate
                else
			SELECT '9' AS Duplicate , var_mastername as ItemName; -- master item duplicate
		end if;
		
		
	END IF;
	
   COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertLoginHistory`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertLoginHistory`( 
arg_UserName NVARCHAR(50),        
arg_IsLogin int,
arg_Comment NVARCHAR(100)
)
BEGIN
declare plogintime datetime;
declare plogouttime datetime;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertLoginHistory');
END;
START TRANSACTION;
set plogintime=null;
set plogouttime=null;
if( arg_IsLogin = 1)	
then
set plogintime = now();
else
set plogouttime = now();
end if;
insert into `tbl_loginhistory` 
(UserName, LogInTime, LogOutTime, LogoutComment)
values
(arg_UserName, plogintime, plogouttime, arg_Comment);
select LAST_INSERT_ID() as ID;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertNameMaster`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertNameMaster`(	 
arg_ItemName NVARCHAR(50)	
)
BEGIN
DECLARE var_name varchar(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertNameMaster');
END;
START TRANSACTION;
select ItemName into var_name from tbl_namemaster where ItemName = arg_ItemName limit 1;
if(var_name is null)
then
insert into tbl_namemaster(ItemName) values(arg_ItemName);
end if;
SELECT 1 AS ID;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertNumberToInventory`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertNumberToInventory`( 
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Expiry NVARCHAR(50)
)
BEGIN
DECLARE var_barcodecheck varchar(100);
DECLARE var_name varchar(100);
declare var_POID int;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_UpdateInventor');
END;
START TRANSACTION;
insert into `tbl_hrf_printed_data_list` 
		(Barcode, ItemName, MRP, SalePrice, Discount, DiscountPercentage, 
		Quantity, HRF_4, HRF_5, HRF_6, HRF_7, HRF_8, HRF_9, HRF_10, HRF_11, 
		HRF_12, HRF_13, HRF_14, HRF_15, ScanStatus, Source)
		select Barcode, ItemName, MRP, SalePrice, Discount, DiscountPercentage, 
		Quantity, HRF_4, HRF_5, HRF_6, HRF_7, HRF_8, HRF_9, HRF_10, HRF_11, 
		HRF_12, HRF_13, HRF_14, HRF_15, ScanStatus, Source from `tbl_hrf_printed_data` where barcode = arg_Barcode;
delete from tbl_hrf_printed_data where Barcode = arg_Barcode;
insert into `tbl_inventory` 
(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, Expiry)
values
(arg_Barcode, arg_ItemName, arg_MRP,arg_BuyPrice, arg_SalePrice, arg_Discount, arg_DiscountPercentage, 
arg_Quantity, arg_Expiry);
SELECT '1' AS Success;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertOrder`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertOrder`( 
arg_OrderNo NVARCHAR(50),        
arg_TaxRate int,
arg_Tax int,
arg_OrderAmount int,        
arg_DealerId int,
arg_OrderDate NVARCHAR(200),
arg_PaidAmount int,
arg_BalanceAmount int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertOrder');
END;
START TRANSACTION;
if( arg_PaidAmount > 0)
then
insert into `tbl_dealer_paid` 
(DealerId, PaymentDate, PaymentAmount)
values
(arg_DealerId, arg_OrderDate, arg_PaidAmount);
end if;
insert into `tbl_order` 
(OrderNo, TaxRate, Tax, OrderAmount, DealerId, OrderDate,PaidAmount,BalanceAmount)
values
(arg_OrderNo, arg_TaxRate, arg_Tax, arg_OrderAmount, arg_DealerId,now() , arg_PaidAmount,arg_BalanceAmount );
select LAST_INSERT_ID() as OrderId;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertOrderDetail`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertOrderDetail`( 
arg_OrderNo NVARCHAR(50),  
arg_ItemName NVARCHAR(50),       
arg_Quantity int,
arg_Rate int,
arg_RateAfterTax double,        
arg_Amount int,
arg_ProfitMargin int,
arg_SalePrice double,        
arg_MRP int,
arg_OrderId int
)
BEGIN
DECLARE var_name varchar(100);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertOrderDetail');
END;
START TRANSACTION;
select ItemName into var_name from tbl_namemaster where ItemName = arg_ItemName limit 1;
if(var_name is null)
then
insert into tbl_namemaster(ItemName) values(arg_ItemName);
end if;
insert into `tbl_orderdetail` 
(OrderId,OrderNo, ItemName, Quantity, Rate, RateAfterTax, Amount, ProfitMargin, SalePrice,MRP)
values
(arg_OrderId, arg_OrderNo, arg_ItemName, arg_Quantity, arg_Rate, arg_RateAfterTax, arg_Amount, arg_ProfitMargin, arg_SalePrice,arg_MRP);
select LAST_INSERT_ID() as ODId;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertOrderPayment`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertOrderPayment`(                  
arg_DealerId int,
arg_PaymentDate NVARCHAR(50),
arg_PaymentAmount int,
arg_OrderNo NVARCHAR(50),
arg_Desc NVARCHAR(100)
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertOrderPayment');
END;
START TRANSACTION;
insert into `tbl_dealer_paid` 
(DealerId, PaymentDate, PaymentAmount,OrderNo,Description)
values
(arg_DealerId, now(), arg_PaymentAmount,arg_OrderNo,arg_Desc);
update tbl_order set PaidAmount = (PaidAmount + arg_PaymentAmount),
BalanceAmount = (BalanceAmount - arg_PaymentAmount) 
where OrderNo = arg_OrderNo;
select 1 as PaymentId;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertOwnLabel`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertOwnLabel`( 
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Expiry NVARCHAR(50)
)
BEGIN
DECLARE var_barcodecheck varchar(100);
DECLARE var_name varchar(100);
declare var_POID int;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_UpdateInventor');
END;
START TRANSACTION;
delete from tbl_inventory_printed where Barcode = arg_Barcode;
insert into `tbl_inventory` 
(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, Expiry)
values
(arg_Barcode, arg_ItemName, arg_MRP,arg_BuyPrice, arg_SalePrice, arg_Discount, arg_DiscountPercentage, 
arg_Quantity, arg_Expiry);
SELECT '1' AS Success;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertPrintHistosry`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertPrintHistosry`( 
arg_PrintedBy NVARCHAR(50),  
arg_DataSource NVARCHAR(50), 
arg_PrintCount int,
arg_PrintItem  NVARCHAR(50), 
arg_ActionAfterPrint  NVARCHAR(50)
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertPrintHistosry');
END;
START TRANSACTION;
insert into `tbl_printinghistory` 
(PrintedBy, PrintDate, DataSource, PrintCount, PrintItem, ActionAfterPrint
)
values
(
arg_PrintedBy, now(), arg_DataSource, arg_PrintCount, arg_PrintItem, arg_ActionAfterPrint
);
select LAST_INSERT_ID() as PhID;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertQuotationCreateInvoice`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertQuotationCreateInvoice`(         
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int
)
BEGIN
DECLARE VAR_INVOICENO NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertSaleCreateInvoice');
END;
START TRANSACTION;
insert into tbl_quotationgeneration(Prifix) values('QUOT');
select CONCAT('QUOT',max(QuotationNo)) INTO VAR_INVOICENO from tbl_quotationgeneration;
insert into  tbl_sale_quotation 
(InvoiceNo, ExtraDiscount, CustomerName, PaymentBy, SGST, CGST, 
DueAmount)
values
(VAR_INVOICENO, 0, VAR_INVOICENO, 'Cash', 0, 0,	0);
insert into tbl_saledetail_quotation
(InvoiceNo, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, 
DiscountPercentage, Quantity, Amount)
values
(VAR_INVOICENO, arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, 
arg_DiscountPercentage, arg_Quantity, arg_Amount);
Select VAR_INVOICENO as InvoiceNumber;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertSale`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertSale`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertSale');
END;
START TRANSACTION;
insert into tbl_saledetail
(InvoiceNo, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, 
DiscountPercentage, Quantity, Amount)
values
(arg_InvoiceNumber, arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, 
arg_DiscountPercentage, arg_Quantity, arg_Amount);
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertSaleCreateInvoice`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertSaleCreateInvoice`(         
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int,
arg_CounterNo int
)
BEGIN
DECLARE VAR_INVOICENO NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertSaleCreateInvoice');
END;
START TRANSACTION;
insert into tbl_invoicenogeneration(Prifix) values('MHE');
select CONCAT('MHE',max(InvoiceNo)) INTO VAR_INVOICENO from tbl_invoicenogeneration;
insert into  tbl_sale 
(InvoiceNo, ExtraDiscount, CustomerName, PaymentBy, SGST, CGST, 
DueAmount,CounterId)
values
(VAR_INVOICENO, 0, VAR_INVOICENO, 'Cash', 0, 0,	0,arg_CounterNo);
insert into tbl_saledetail
(InvoiceNo, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, 
DiscountPercentage, Quantity, Amount)
values
(VAR_INVOICENO, arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, 
arg_DiscountPercentage, arg_Quantity, arg_Amount);
Select VAR_INVOICENO as InvoiceNumber;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertSale_Quotation`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertSale_Quotation`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertSale');
END;
START TRANSACTION;
insert into tbl_saledetail_quotation
(InvoiceNo, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, 
DiscountPercentage, Quantity, Amount)
values
(arg_InvoiceNumber, arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, 
arg_DiscountPercentage, arg_Quantity, arg_Amount);
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertUpdateScanner`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertUpdateScanner`( 
arg_ComPort NVARCHAR(50),
arg_BaudRate NVARCHAR(50),	 
arg_Parity NVARCHAR(50), 
arg_DataBits NVARCHAR(50),
arg_StopBits NVARCHAR(50),
arg_Flow NVARCHAR(50),
arg_DeviceNumber NVARCHAR(50),
arg_CounterId int
)
BEGIN
declare var_POID int;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertUpdateScanner');
END;
START TRANSACTION;
update tbl_scannersettings 
set DataBits=arg_DataBits, 
ComPort = arg_ComPort,		
Flow=arg_Flow,
Parity=arg_Parity,
PrinterIp='',
PrinterPort='',
BaudRate=arg_BaudRate,
StopBits=arg_StopBits where devicenumber=arg_DeviceNumber and CounterId = arg_CounterId;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_InsertUpdateUser`;
DELIMITER |
CREATE PROCEDURE `Sp_InsertUpdateUser`(
arg_LoginUser nvarchar(100),
arg_UserID int,
arg_DisplayName nvarchar(100),
arg_UserName nvarchar(50),
arg_Password nvarchar(50),
arg_GroupID int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_InsertUpdateUser');
END;
START TRANSACTION;
if( arg_UserID = 0 ) then
insert into `tbl_useraudit` 
(AdminName, Actions, ActionDate)
values
(arg_LoginUser, concat('1 user created. user name is ',arg_DisplayName), now());
insert into `tbl_moduleaccess` 
(DisplayName, username, userpass, groupId, IsActive)
values
(arg_DisplayName, arg_UserName, arg_Password, arg_GroupID, 1);
select LAST_INSERT_ID() as UserId;
else
insert into `tbl_useraudit` 
(AdminName, Actions, ActionDate)
values
(arg_LoginUser, concat('1 user updated. user name is ',arg_DisplayName), now());
update tbl_moduleaccess set DisplayName = arg_DisplayName ,username = arg_UserName 
,userpass = arg_Password , groupId = arg_GroupID where  ID = arg_UserID ; 
select arg_UserID as UserId;
end if;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetExchangeReturn`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetExchangeReturn`(
arg_ItemName NVARCHAR(50)
)
BEGIN
select T.ItemName,T.Return_Count ,T.Remark
,ifnull(M.Name,'') as `Dealer Name` 
,ifnull(M.Mobile,'') as `Mobile` ,ifnull(M.Address,'') as `Address` from 
(
select sd.Itemname ,count(1) as Return_Count , Remark from tbl_saledetail sd
where sd.Remark is not  null
group by sd.Itemname,sd.Remark
) as T
left join 
(
select distinct od.ItemName,Name,Mobile,Address from tbl_order om
inner join tbl_orderdetail od on om.OrderNo=od.OrderNo
inner join tbl_dealer d on d.id= om.DealerId	    
) as M on T.ItemName = M.ItemName        
order by T.ItemName asc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetGSTSale`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetGSTSale`(
arg_ItemName NVARCHAR(50)
)
BEGIN
select InvoiceNo,'GST' as BillType,  PaymentBy ,CustomerName,CustomerMobile, PaidAmount as BillAmount, 
'Paid' as `Status`, `Date` as SaleDate
from 
`tbl_sale`  where `status` = 'Complete' and GST > 0   
order by InvoiceNo desc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetInventoryRunningLowNameList`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetInventoryRunningLowNameList`(
arg_ItemName NVARCHAR(50)
)
BEGIN
select T.ItemName,T.AvaibleQty as `Avaible_Quantity`, case when mu.ItemName <> '' then 'Yes' else 'No' end `Is Master Item?` 
,ifnull(M.Name,'') as `Dealer Name` 
,ifnull(M.Mobile,'') as `Mobile` ,ifnull(M.Address,'') as `Address` from 
(
select ItemName,MRP,sum(Quantity) as AvaibleQty from tbl_inventory 
group by  ItemName,MRP	
) as T
left join 
(
select distinct od.ItemName,Name,Mobile,Address from tbl_order om
inner join tbl_orderdetail od on om.OrderNo=od.OrderNo
inner join tbl_dealer d on d.id= om.DealerId	    
) as M on T.ItemName = M.ItemName 
left join tbl_inventorymasterunit mu on T.ItemName = mu.ItemName
where T.AvaibleQty < 5
order by T.ItemName asc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetLoginHistory`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetLoginHistory`(
arg_ItemName NVARCHAR(50)
)
BEGIN
select 	 UserName as `USer Name`, LogInTime as `LogIn Time`, LogOutTime as `LogOut Time`, LogoutComment as `Logout Comment`
from 
`tbl_loginhistory` order by id desc limit 100;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetMonthWiseExchange`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetMonthWiseExchange`(
)
BEGIN
select m.MonthText,ifnull(s.Sale,0) as Sale from
(
select MONTHNAME(`date`) as MonthT,  sum(ifnull(ExcAmount,0)) as Sale from tbl_sale where year(`date`) = YEAR(CURDATE())
) as s
right outer join tbl_months m on s.MonthT = m.MonthText;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetMonthWiseItemSale`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetMonthWiseItemSale`(
)
BEGIN
select ItemName,ifnull(s.Sale,0) as Sale from
(
select MONTHNAME(`date`) as MonthT,  sum(ifnull(Amount,0)) as Sale ,ds.ItemName
from tbl_sale  sa inner join tbl_SaleDetail ds on sa.InvoiceNo = ds.InvoiceNo and ds.ItemId > 0
where year(`date`) = YEAR(CURDATE()) group by ds.ItemId
) as s;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetMonthWiseSale`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetMonthWiseSale`(
)
BEGIN
select m.MonthText,ifnull(s.Sale,0) as Sale from
(
select MONTHNAME(`date`) as MonthT,  sum(PaidAmount) as Sale from tbl_sale where year(`date`) = YEAR(CURDATE())
) as s
right outer join tbl_months m on s.MonthT = m.MonthText;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetNoneGSTSale`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetNoneGSTSale`(
arg_ItemName NVARCHAR(50)
)
BEGIN
select InvoiceNo,'None GST' as BillType,  PaymentBy , PaidAmount as BillAmount, 
'Paid' as `Status`, `Date` as SaleDate
from 
`tbl_sale`  where `status` = 'Complete' and GST=0   
order by InvoiceNo desc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetOutOfStock`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetOutOfStock`(
arg_ItemName NVARCHAR(50)
)
BEGIN
select T.ItemName as `Item Name`,T.AvaibleQty as `Avaible Quantity`, case when mu.ItemName <> '' then 'Yes' else 'No' end `Is Master Item?` 
,ifnull(M.Name,'') as `Dealer Name` 
,ifnull(M.Mobile,'') as `Mobile` ,ifnull(M.Address,'') as `Address` from 
(
select nm.Itemname ,0 as AvaibleQty from tbl_namemaster nm
left join tbl_inventory it on it.ItemName = nm.ItemName  where it.ItemName is  null
) as T
left join 
(
select distinct od.ItemName,Name,Mobile,Address from tbl_order om
inner join tbl_orderdetail od on om.OrderNo=od.OrderNo
inner join tbl_dealer d on d.id= om.DealerId	    
) as M on T.ItemName = M.ItemName 
left join tbl_inventorymasterunit mu on T.ItemName = mu.ItemName
order by T.ItemName asc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetPurchaseInvoiceList`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetPurchaseInvoiceList`(
arg_ItemName NVARCHAR(50)
)
BEGIN
select  o.OrderDate,d.Name as DealerName,od.OrderNo as InvoiceNo,PGSTNo,o.tax as GST_Amount,o.OrderAmount as `Total BillAmount`
,od.ItemName,od.Quantity,od.Rate,od.RateAfterTax
,od.Amount as `Item Amount`,od.SalePrice,od.MRP, Mobile, MobileAlt, Address
from `tbl_dealer` d
inner join tbl_order o on d.ID=o.dealerid
inner join tbl_orderdetail od on od.OrderId= o.ID
where o.BalanceAmount = 0
order by o.ID desc;	
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetPurchaseInvoiceListNotPaid`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetPurchaseInvoiceListNotPaid`(
arg_ItemName NVARCHAR(50)
)
BEGIN
select  o.OrderDate,d.Name as DealerName,od.OrderNo as InvoiceNo,PGSTNo,o.tax as GST_Amount,o.OrderAmount as `Total BillAmount`
,od.ItemName,od.Quantity,od.Rate,od.RateAfterTax
,od.Amount as `Item Amount`,od.SalePrice,od.MRP, Mobile, MobileAlt, Address
from `tbl_dealer` d
inner join tbl_order o on d.ID=o.dealerid
inner join tbl_orderdetail od on od.OrderId= o.ID
where o.BalanceAmount > 0 
order by o.ID desc;	
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetStockOnHand`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetStockOnHand`()
BEGIN
select T.ItemName,T.AvaibleQty as `Avaible_Quantity`, case when mu.ItemName <> '' then 'Yes' else 'No' end `Is Master Item?` 
,ifnull(M.Name,'') as `Dealer Name` 
,ifnull(M.Mobile,'') as `Mobile` ,ifnull(M.Address,'') as `Address`  from
(
select ItemName, sum(Quantity) as AvaibleQty from  tbl_inventory
group by ItemName
union all 
select nm.Itemname , 0 as AvaibleQty from tbl_namemaster nm
left join tbl_inventory it on it.ItemName = nm.ItemName 
where it.ItemName is  null 
) as T 
left join 
(
select distinct od.ItemName,Name,Mobile,Address from tbl_order om
inner join tbl_orderdetail od on om.OrderNo=od.OrderNo
inner join tbl_dealer d on d.id= om.DealerId	    
) as M on T.ItemName = M.ItemName 
left join tbl_inventorymasterunit mu on T.ItemName = mu.ItemName
order by T.AvaibleQty desc;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_GetUserActionHistory`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_GetUserActionHistory`(
arg_ItemName NVARCHAR(50)
)
BEGIN
select 	 AdminName as `Admin Name`, Actions, ActionDate as `Action Date`
from 
`tbl_useraudit` order by ID desc ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Report_PaymentHistory`;
DELIMITER |
CREATE PROCEDURE `Sp_Report_PaymentHistory`(
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_Report_PaymentHistory');
END;
START TRANSACTION;
select 	 LoginUser, Customer, InvoiceNumner,TotalBill, PaidAmount, DueAmount, DiscountOnBill,  `Date` 
from 
`tbl_salehistory` 
where   TotalBill <> PaidAmount
order by InvoiceNumner desc;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_TodaysSale`;
DELIMITER |
CREATE PROCEDURE `Sp_TodaysSale`(
)
BEGIN
select ifnull(sum(PaidAmount),0) as PaidAmount, ifnull(sum(DueAmount),0) as DueAmount 
from tbl_sale 
where isdeleted = 0 and `status` <> 'Inprogress' and convert(`Date`,date) = CURRENT_DATE  ;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_TruncateInprogressInventory`;
DELIMITER |
CREATE PROCEDURE `Sp_TruncateInprogressInventory`()
BEGIN
truncate table tbl_inventory_inprogress;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_Update1Plus1Discount`;
DELIMITER |
CREATE PROCEDURE `Sp_Update1Plus1Discount`(          
arg_ItemId int
)
BEGIN
declare varbacode NVARCHAR(50);
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_Update1Plus1Discount');
END;
START TRANSACTION;
update  tbl_inventory set Is1Plus1Discount = 1 where Id = arg_ItemId;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_UpdateExcahngeSaleDetail`;
DELIMITER |
CREATE PROCEDURE `Sp_UpdateExcahngeSaleDetail`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_Barcode NVARCHAR(50),
arg_OldBarcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_UpdateExcahngeSaleDetail');
END;
START TRANSACTION;
insert into `tbl_saledetail` 
(InvoiceNo, Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, 
DiscountPercentage, Quantity, Amount, Remark)
values
(arg_InvoiceNumber, arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, 
arg_DiscountPercentage, arg_Quantity, arg_Amount, 'Behaf of Exchange');
insert into `tbl_inventory_sold` 
(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity,Expiry)
values
(arg_Barcode, arg_ItemName, arg_MRP, arg_BuyPrice, arg_SalePrice, arg_Discount, 
arg_DiscountPercentage, arg_Quantity,now());
delete from tbl_inventory where barcode = arg_Barcode and Quantity = 1;
update tbl_saledetail set Amount = 0 , Remark = 'Exchanged' where barcode = arg_OldBarcode;
insert into tbl_inventory(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, Expiry) select Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, Expiry from tbl_inventory_sold where barcode = arg_OldBarcode;
delete from tbl_inventory_sold where barcode = arg_OldBarcode;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_UpdateHRFInstruction`;
DELIMITER |
CREATE PROCEDURE `Sp_UpdateHRFInstruction`( 
arg_HRF_Code varchar(10),        
arg_Show_Hide bool
)
BEGIN
update tbl_hrf_instruction set Show_Hide = arg_Show_Hide where HRF_Code = arg_HRF_Code;
select 1 As ID;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_UpdateHRFPritingData`;
DELIMITER |
CREATE PROCEDURE `Sp_UpdateHRFPritingData`(
arg_Barcode varchar(50),
arg_HRF_1 varchar(50),
arg_HRF_2 varchar(50),
arg_HRF_3 varchar(50),
arg_HRF_4 varchar(50),
arg_HRF_5 varchar(50),
arg_HRF_6 varchar(50),
arg_HRF_7 varchar(50),
arg_HRF_8 varchar(50),
arg_HRF_9 varchar(50),
arg_HRF_10 varchar(50),
arg_HRF_11 varchar(50),
arg_HRF_12 varchar(50),
arg_HRF_13 varchar(50),
arg_HRF_14 varchar(50),
arg_HRF_15 varchar(50),
arg_Print_Quantity int,
arg_ID int
)
BEGIN
update `tbl_hrf_printing_data` 
set Barcode = arg_Barcode,HRF_1 = arg_HRF_1, HRF_2 = arg_HRF_2, HRF_3 = arg_HRF_3, HRF_4 = arg_HRF_4, HRF_5 = arg_HRF_5,
HRF_6 = arg_HRF_6, HRF_7 = arg_HRF_7, HRF_8 = arg_HRF_8, HRF_9 = arg_HRF_9, HRF_10 = arg_HRF_10, HRF_11 = arg_HRF_11,
HRF_12 = arg_HRF_12, HRF_13 = arg_HRF_13, HRF_14 = arg_HRF_14, HRF_15 = arg_HRF_15,Print_Quantity = arg_Print_Quantity where ID = arg_ID ;
select arg_ID as ppid;
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_UpdateInventor`;
DELIMITER |
CREATE PROCEDURE `Sp_UpdateInventor`( 
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Expiry NVARCHAR(50)
)
BEGIN
DECLARE var_barcodecheck varchar(100);
DECLARE var_name varchar(100);
declare var_POID int;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_UpdateInventor');
END;
START TRANSACTION;
set var_barcodecheck ='';
select barcode into var_barcodecheck from tbl_inventory where barcode= arg_Barcode limit 1;
IF (var_barcodecheck <> '')
then
update `tbl_inventory` set
ItemName = arg_ItemName, MRP = arg_MRP, BuyPrice = arg_BuyPrice, SalePrice = arg_SalePrice, Discount = arg_Discount,
DiscountPercentage = arg_DiscountPercentage, Quantity = arg_Quantity where  barcode = arg_Barcode;
select ItemName into var_name from tbl_namemaster where ItemName = arg_ItemName limit 1;
if(var_name is null)
then
insert into tbl_namemaster(ItemName) values(arg_ItemName);
end if;
if ( arg_Quantity > 1)
then
if(select barcode from tbl_inventoryMasterUnit  where barcode= arg_Barcode)
then
update `tbl_inventoryMasterUnit` set
ItemName = arg_ItemName, MRP = arg_MRP, BuyPrice = arg_BuyPrice, SalePrice = arg_SalePrice, Discount = arg_Discount,
DiscountPercentage = arg_DiscountPercentage, Quantity = arg_Quantity where  barcode = arg_Barcode;
else
insert into `tbl_inventoryMasterUnit` 
(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, Expiry)
values
(arg_Barcode, arg_ItemName, arg_MRP,arg_BuyPrice, arg_SalePrice, arg_Discount, arg_DiscountPercentage, 
arg_Quantity, arg_Expiry);
end if;
else
delete from tbl_inventoryMasterUnit  where barcode= arg_Barcode;
end if;
SELECT '1' AS Success;
ELSE
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Barcodenotfound', null, null,null,arg_Barcode);
SELECT '0' AS Success;
END IF;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_UpdateModuleAccess`;
DELIMITER |
CREATE PROCEDURE `Sp_UpdateModuleAccess`( 
arg_GroupID int,
arg_ModuleID int,         
arg_Access bool,
arg_LoginUser nvarchar(50),
arg_ModuleName nvarchar(50),
arg_GroupName nvarchar(50)
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_UpdateModuleAccess');
END;
START TRANSACTION;
insert into `tbl_useraudit` 
(AdminName, Actions, ActionDate)
values
(arg_LoginUser, concat('Updated ',arg_GroupName,' module access( ',arg_ModuleName,' ,', arg_Access,' )' ), now());
update tbl_appmoduleaccess set access=arg_Access where groupid=arg_GroupID and moduleID = arg_ModuleID;
select 1 as ID;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_UpdateQuotationDetail`;
DELIMITER |
CREATE PROCEDURE `Sp_UpdateQuotationDetail`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_ExtraDiscount int,
arg_CustomerName NVARCHAR(50),
arg_PaymentBy NVARCHAR(20),	 
arg_GST int, 
arg_DueAmount int,
arg_Status NVARCHAR(50),
arg_PaidAmount int,
arg_CustomerMobile NVARCHAR(50),
arg_CustomerGST NVARCHAR(50),
arg_LoginUser  NVARCHAR(50)
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_UpdateQuotationDetail');
END;
START TRANSACTION;
update tbl_sale_quotation set 
ExtraDiscount = arg_ExtraDiscount, 
CustomerName = arg_CustomerName, PaymentBy = arg_PaymentBy,
GST = arg_GST, DueAmount = arg_DueAmount,`Status` = arg_Status,
PaidAmount = arg_PaidAmount,CustomerMobile= arg_CustomerMobile, CustomerGST = arg_CustomerGST
where InvoiceNo = arg_InvoiceNumber;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_UpdateReturnSaleDetail`;
DELIMITER |
CREATE PROCEDURE `Sp_UpdateReturnSaleDetail`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_Barcode NVARCHAR(50),	 
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_UpdateReturnSaleDetail');
END;
START TRANSACTION;
update tbl_saledetail set Amount = 0 , Remark = 'Returned' where barcode = arg_Barcode;
insert into tbl_inventory(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, Expiry) select Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
Quantity, Expiry from tbl_inventory_sold where barcode = arg_Barcode;
delete from tbl_inventory_sold where barcode = arg_Barcode;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_UpdateSale`;
DELIMITER |
CREATE PROCEDURE `Sp_UpdateSale`( 
arg_InvoiceNumber NVARCHAR(50),        
arg_Barcode NVARCHAR(50),
arg_ItemName NVARCHAR(50),
arg_MRP int,	 
arg_BuyPrice int, 
arg_SalePrice int,
arg_Discount int,
arg_DiscountPercentage int,
arg_Quantity int,
arg_Amount int
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_UpdateSale');
END;
START TRANSACTION;
update tbl_saledetail set 
Discount = arg_Discount, 
Quantity =arg_Quantity, Amount = arg_Amount where Barcode = arg_Barcode and InvoiceNo = arg_InvoiceNumber;
Select 'Success' as result;
COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_UpdateSaleDetail`;
DELIMITER |
CREATE PROCEDURE `Sp_UpdateSaleDetail`( 
         arg_InvoiceNumber NVARCHAR(50),        
	 arg_ExtraDiscount int,
	 arg_CustomerName NVARCHAR(50),
         arg_PaymentBy NVARCHAR(20),	 
	 arg_GST int, 
	 arg_DueAmount int,
	 arg_Status NVARCHAR(50),
	 arg_PaidAmount int,
	 arg_CustomerMobile NVARCHAR(50),
	 arg_CustomerGST NVARCHAR(50),
         arg_LoginUser  NVARCHAR(50)
	)
BEGIN
  declare varuserid int;  
  DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
	 ROLLBACK;
	Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
	 values(null,null,'Error ocured', null, null,null,'Sp_UpdateSaleDetail');
	
          
    END;
	
   START TRANSACTION;
	select id into varuserid from tbl_moduleaccess where DisplayName = arg_LoginUser limit 1;
      update tbl_sale set 
	ExtraDiscount = arg_ExtraDiscount, 
	CustomerName = arg_CustomerName, PaymentBy = arg_PaymentBy,
	GST = arg_GST, DueAmount = arg_DueAmount,`Status` = arg_Status,
	PaidAmount = arg_PaidAmount,CustomerMobile= arg_CustomerMobile, CustomerGST = arg_CustomerGST,userid = varuserid
        where InvoiceNo = arg_InvoiceNumber;
       	
	insert into `uttambillbook`.`tbl_inventory_sold` 
	(Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, 
	Quantity, Expiry)
	select 	 Barcode, ItemName, MRP, BuyPrice, SalePrice, Discount, DiscountPercentage, Quantity, Expiry 
	from vtbl_soldbarcods where InvoiceNo = arg_InvoiceNumber and Quantity = 1;
       delete from tbl_inventory where Quantity = 1 and barcode in(
		select tbl_saledetail.barcode  from tbl_saledetail left join tbl_inventorymasterunit on tbl_saledetail.barcode=tbl_inventorymasterunit.barcode 
		where tbl_inventorymasterunit.barcode is null and InvoiceNo = arg_InvoiceNumber
		);
	update tbl_inventory set Quantity = Quantity -1 where barcode in(
		select tbl_saledetail.barcode from tbl_saledetail inner join tbl_inventorymasterunit on tbl_saledetail.barcode=tbl_inventorymasterunit.barcode
		where InvoiceNo = arg_InvoiceNumber
		);
	insert into `uttambillbook`.`tbl_salehistory` 
	(LoginUser, Customer, TotalBill, PaidAmount, DueAmount, DiscountOnBill, 
	InvoiceNumner, Date)
	values
	(arg_LoginUser, arg_CustomerName, (arg_ExtraDiscount+arg_DueAmount+arg_PaidAmount), arg_PaidAmount, arg_DueAmount, arg_ExtraDiscount, 
	arg_InvoiceNumber, now());
       Select 'Success' as result;
   COMMIT; 
END |
DELIMITER ;

DROP PROCEDURE IF EXISTS `Sp_UpdateShopeVariable`;
DELIMITER |
CREATE PROCEDURE `Sp_UpdateShopeVariable`(
arg_Key nvarchar(50),
arg_Value nvarchar(500)
)
BEGIN
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
BEGIN
ROLLBACK;
Insert into TBL_ErrorLog (ErrorNumber,ErrorLine,ErrorMessage,ErrorSeverity,ErrorState,createdOn,ProcedureName)
values(null,null,'Error ocured', null, null,null,'Sp_UpdateShopeVariable');
END;
START TRANSACTION;
update `tbl_appsetup` set VariableValue = arg_Value where VariableKey =  arg_Key ;
select 1 As ID;
COMMIT; 
END |
DELIMITER ;

-- 
-- Dumping views
-- 

DROP TABLE IF EXISTS `vtbl_hrf_instructionexten`;
DROP VIEW IF EXISTS `vtbl_hrf_instructionexten`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vtbl_hrf_instructionexten` AS select `tbl_hrf_instruction`.`ID` AS `ID`,`tbl_hrf_instruction`.`HRF_Code` AS `HRF_Code`,`tbl_hrf_instruction`.`HRF_Name` AS `HRF_Name`,`tbl_hrf_instruction`.`Show_Hide` AS `Show_Hide`,(case when (`tbl_hrf_instruction`.`HRF_Code` = 'HRF_1') then `tbl_hrf_instruction`.`HRF_Name` end) AS `HRF_1`,(case when (`tbl_hrf_instruction`.`HRF_Code` = 'HRF_2') then `tbl_hrf_instruction`.`HRF_Name` end) AS `HRF_2`,(case when (`tbl_hrf_instruction`.`HRF_Code` = 'HRF_3') then `tbl_hrf_instruction`.`HRF_Name` end) AS `HRF_3`,(case when (`tbl_hrf_instruction`.`HRF_Code` = 'HRF_4') then `tbl_hrf_instruction`.`HRF_Name` end) AS `HRF_4`,(case when (`tbl_hrf_instruction`.`HRF_Code` = 'HRF_5') then `tbl_hrf_instruction`.`HRF_Name` end) AS `HRF_5`,(case when (`tbl_hrf_instruction`.`HRF_Code` = 'HRF_6') then `tbl_hrf_instruction`.`HRF_Name` end) AS `HRF_6`,(case when (`tbl_hrf_instruction`.`HRF_Code` = 'HRF_7') then `tbl_hrf_instruction`.`HRF_Name` end) AS `HRF_7`,(case when (`tbl_hrf_instruction`.`HRF_Code` = 'HRF_8') then `tbl_hrf_instruction`.`HRF_Name` end) AS `HRF_8`,(case when (`tbl_hrf_instruction`.`HRF_Code` = 'HRF_9') then `tbl_hrf_instruction`.`HRF_Name` end) AS `HRF_9`,(case when (`tbl_hrf_instruction`.`HRF_Code` = 'HRF_10') then `tbl_hrf_instruction`.`HRF_Name` end) AS `HRF_10` from `tbl_hrf_instruction`;

DROP TABLE IF EXISTS `vtbl_module_access`;
DROP VIEW IF EXISTS `vtbl_module_access`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vtbl_module_access` AS select `m`.`IsActive` AS `IsActive`,`ma`.`GroupID` AS `groupid`,`ma`.`ModuleID` AS `moduleid`,`m`.`ModuleCode` AS `modulecode`,`m`.`ModuleName` AS `modulename`,`ma`.`Access` AS `access`,`m`.`Sequence` AS `Sequence`,`m`.`Tcolor` AS `Tcolor`,`m`.`Bcolor` AS `Bcolor`,`m`.`MImage` AS `MImage` from (`tbl_appmoduleaccess` `ma` join `tbl_appmodule` `m` on((`ma`.`ModuleID` = `m`.`ModuleID`)));

DROP TABLE IF EXISTS `vtbl_sale_gb_cputd`;
DROP VIEW IF EXISTS `vtbl_sale_gb_cputd`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vtbl_sale_gb_cputd` AS select cast(`tbl_sale`.`Date` as date) AS `SaleDate`,`tbl_sale`.`CounterId` AS `CounterId`,`tbl_sale`.`PaymentBy` AS `PaymentBy`,`tbl_sale`.`UserId` AS `UserId`,`tbl_sale`.`TransactionType` AS `TransactionType`,sum(`tbl_sale`.`CashPay`) AS `CashPayment`,sum(`tbl_sale`.`CardPay`) AS `CardPayment`,sum(`tbl_sale`.`UPIPay`) AS `UPIPayment` from `tbl_sale` where (`tbl_sale`.`Status` <> 'Inprogress') group by `tbl_sale`.`CounterId`,`tbl_sale`.`PaymentBy`,`tbl_sale`.`UserId`,`tbl_sale`.`TransactionType`,cast(`tbl_sale`.`Date` as date) order by `tbl_sale`.`Date`;

DROP TABLE IF EXISTS `vtbl_saleinprogress`;
DROP VIEW IF EXISTS `vtbl_saleinprogress`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vtbl_saleinprogress` AS select `sd`.`Barcode` AS `Barcode` from (`tbl_saledetail` `sd` join `tbl_sale` `s` on(((`sd`.`InvoiceNo` = `s`.`InvoiceNo`) and (`s`.`Status` = 'Inprogress'))));

DROP TABLE IF EXISTS `vtbl_soldbarcods`;
DROP VIEW IF EXISTS `vtbl_soldbarcods`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vtbl_soldbarcods` AS select `sd`.`InvoiceNo` AS `InvoiceNo`,`it`.`Barcode` AS `Barcode`,`it`.`ItemName` AS `ItemName`,`it`.`MRP` AS `MRP`,`it`.`BuyPrice` AS `BuyPrice`,`it`.`SalePrice` AS `SalePrice`,`it`.`Discount` AS `Discount`,`it`.`DiscountPercentage` AS `DiscountPercentage`,`it`.`Quantity` AS `Quantity`,`it`.`Expiry` AS `Expiry` from (`tbl_inventory` `it` join `tbl_saledetail` `sd` on((`it`.`Barcode` = `sd`.`Barcode`)));



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


-- Dump completed on 2025-06-30 00:00:05
-- Total time: 0:0:0:0:397 (d:h:m:s:ms)
